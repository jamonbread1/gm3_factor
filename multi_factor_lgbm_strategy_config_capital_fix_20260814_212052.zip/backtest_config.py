# -*- coding: utf-8 -*-
"""GM3 backtest range. Edit only these two values before local/terminal backtests."""

START = "2012-01-01"
END = "2026-08-13"


def validate_date_range(start=START, end=END):
    import datetime as _dt
    s = _dt.datetime.strptime(start, "%Y-%m-%d")
    e = _dt.datetime.strptime(end, "%Y-%m-%d")
    if s >= e:
        raise ValueError("START 必须早于 END: %s >= %s" % (start, end))
    return start, end
