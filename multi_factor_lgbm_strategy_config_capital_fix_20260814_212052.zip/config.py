# -*- coding: utf-8 -*-
"""V6.2 risk-first configuration for GM3.

INIT_CAPITAL is the backtest starting cash. Runtime portfolio limits are
resolved dynamically by strategy.portfolio.capital_profile(nav).
"""
import os

# ---- Starting capital (set to your real / intended size) ----
INIT_CAPITAL = 50_000
INDEX_SYMBOL = "SHSE.000300"

# Static fallbacks. Active strategies use capital_profile(nav) at runtime,
# so these values are compatibility defaults rather than hard overrides.
MAX_POSITION_STOCK = 3
MAX_DAILY_BUY = 2
MAX_POSITION_PCT = 0.28
MIN_POSITION_PCT = 0.12
HOLD_DAYS = 15
TURNOVER_CAP = 0.55
MIN_CASH_RESERVE_PCT = 0.10
LOT_SIZE = 100

# Alpha / sizing defaults
MA_LONG = 20
ATR_BARS = 40
ATR_PERIOD = 14
RISK_PER_TRADE = 0.015
ENABLE_RISK_BUDGET = True
ENABLE_SCORE_SIZING = True
MIN_BUY_SCORE = 0.55
SCORE_FULL_CAP = 0.85
POS_MULT_MIN = 0.50
ONE_LOT_MAX_OVERSHOOT = 1.08

# Exit engine
HARD_STOP_PCT = 0.07
ATR_STOP_MULT = 3.0
STRUCT_STOP_ENABLE = True
STRUCT_STOP_LOOKBACK = 12
STRUCT_STOP_BUFFER = 0.01
ENABLE_MA20_EXIT = False
ENABLE_RISK_EXIT = True
ENABLE_PARTIAL_TP = False
PARTIAL_TP_PCT = 0.12
PARTIAL_RATIO = 0.50
PROFIT_LOCK_PCT = 0.12
TRAIL_STOP_PCT = 0.08

# Portfolio circuit breaker
PORTFOLIO_DD_WARN = 0.10
PORTFOLIO_DD_DELEVERAGE = 0.15
PORTFOLIO_DD_STOP = 0.20
DELEVERAGE_MULTIPLIER = 0.35

REGIME_MULTIPLIERS = {
    "strong": 1.00,
    "range": 0.75,
    "weak": 0.50,
    "bear": 0.25,
}

COMMISSION_RATIO = 0.0001
SLIPPAGE_RATIO = 0.0002
BACKTEST_MATCH_MODE = 1
# GM main.py passes the GM enum ADJUST_PREV directly at run() time.
BACKTEST_ADJUST = "ADJUST_PREV"

GM_TOKEN = os.getenv("GM_TOKEN", "")
