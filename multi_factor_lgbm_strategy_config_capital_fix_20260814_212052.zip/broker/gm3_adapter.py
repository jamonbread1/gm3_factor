# -*- coding: utf-8 -*-
"""GM3 3.x adapter.

Important: GM Python exposes enum constants such as OrderSide_Buy rather than
Python Enum classes such as OrderSide.  This adapter intentionally imports the
public constants documented by GM3.
"""
from gm.api import (
    OrderSide_Buy,
    OrderSide_Sell,
    OrderType_Market,
    PositionEffect_Open,
    PositionEffect_Close,
    PositionSide_Long,
)
from gm.api import current, order_volume

from strategy.lot_rules import min_lot_size, round_lot


class GM3Broker:
    def __init__(self, context):
        self.context = context

    @staticmethod
    def _get(obj, key, default=None):
        if obj is None:
            return default
        if isinstance(obj, dict):
            return obj.get(key, default)
        try:
            return getattr(obj, key)
        except Exception:
            return default

    def positions(self):
        """Return account positions as normalized dicts."""
        try:
            positions = self.context.account().positions()
        except Exception:
            positions = []
        result = []
        for p in positions or []:
            result.append({
                "symbol": self._get(p, "symbol", ""),
                "volume": int(self._get(p, "volume", 0) or 0),
                "available": int(self._get(p, "available", 0) or 0),
                "vwap": float(self._get(p, "vwap", 0) or 0),
                "price": float(self._get(p, "price", 0) or 0),
                "amount": float(self._get(p, "amount", 0) or 0),
                "side": self._get(p, "side", PositionSide_Long),
            })
        return result

    def cash(self):
        """Available cash, not total account net asset value."""
        try:
            cash = self.context.account().cash
            available = self._get(cash, "available", None)
            if available is not None:
                return float(available)
            return float(self._get(cash, "nav", 0) or 0)
        except Exception:
            return 0.0

    def total_asset(self):
        """Account NAV. Prefer Cash.nav when available."""
        try:
            cash = self.context.account().cash
            nav = self._get(cash, "nav", None)
            if nav is not None and float(nav) > 0:
                return float(nav)
        except Exception:
            pass
        total = self.cash()
        for p in self.positions():
            total += float(p.get("amount", 0) or 0)
        return total

    def market_price(self, symbol):
        data = current(symbols=symbol, fields="symbol,price")
        if not data:
            return 0.0
        return float(data[0].get("price", 0) or 0)

    def history(self, symbol, count, fields="close,high,low,volume"):
        return self.context.data(symbol=symbol, frequency="1d", count=count, fields=fields)

    def buy(self, symbol, volume):
        lot = min_lot_size(symbol)
        volume = round_lot(int(volume), symbol)
        if volume < lot:
            print("SKIP BUY LOT | %s | volume below board min %d" % (symbol, lot))
            return []
        return order_volume(
            symbol=symbol,
            volume=int(volume),
            side=OrderSide_Buy,
            order_type=OrderType_Market,
            position_effect=PositionEffect_Open,
        )

    def sell_all(self, symbol):
        position = next((p for p in self.positions() if p["symbol"] == symbol), None)
        if not position:
            return []
        available = int(position.get("available", position.get("volume", 0)) or 0)
        if available <= 0:
            return []
        return order_volume(
            symbol=symbol,
            volume=available,
            side=OrderSide_Sell,
            order_type=OrderType_Market,
            position_effect=PositionEffect_Close,
        )

    def sell_volume(self, symbol, volume):
        position = next((p for p in self.positions() if p["symbol"] == symbol), None)
        if not position:
            return []
        available = int(position.get("available", position.get("volume", 0)) or 0)
        volume = min(int(volume), available)
        if volume <= 0:
            return []
        return order_volume(
            symbol=symbol,
            volume=volume,
            side=OrderSide_Sell,
            order_type=OrderType_Market,
            position_effect=PositionEffect_Close,
        )
