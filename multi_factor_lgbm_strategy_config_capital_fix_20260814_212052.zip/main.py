# -*- coding: utf-8 -*-
"""GM3 V6.3 entry — thin dispatcher. Plugins do the real work.

Edit backtest_config.py for date range. Edit config.py for capital / risk.
Swap plugins in the register() block below.

支持策略：
  - MagicNineStrategy（默认，原有）
  - MultiFactorLightGBMStrategy（72+因子 LightGBM Rank 选股）
  - MultiFactorMagicNineExperimentalStrategy（多因子选股 + 九转风控）
  - DefaultStrategy
"""
import datetime
import importlib.util
import os
import sys
import pandas as pd

# 允许无 gm 环境下导入本文件做 demo
try:
    from gm.api import *
    HAS_GM = True
except ImportError:
    HAS_GM = False

import config
import backtest_config as bt
from plugins import registry
from plugins.strategy.default_v5 import DefaultStrategy
from plugins.strategy.magic_nine import MagicNineStrategy
from plugins.strategy.multi_factor_lgbm import MultiFactorLightGBMStrategy
from plugins.strategy.multi_factor_magic9_experimental import MultiFactorMagicNineExperimentalStrategy
from plugins.sl.atr_structure import ATRStructureSL
from plugins.tp.trail_partial import TrailPartialTP
from plugins.risk.portfolio_dd import PortfolioDDRisk

# ---- 策略切换：改为 "multi_factor_lgbm" 即可启用多因子 LightGBM ----
ACTIVE_STRATEGY = os.getenv("ACTIVE_STRATEGY", "multi_factor_lgbm")  # magic_nine | multi_factor_lgbm | multi_factor_magic9_experimental | default_v5

# 动态发现（不破坏原有注册）
try:
    discovered = registry.discover_plugins()
    print("DISCOVERED PLUGINS | %s" % list(discovered.keys()))
except Exception as e:
    print("WARN discover | %s" % e)
    discovered = {}

# ---- Plugin registration ----
if ACTIVE_STRATEGY == "multi_factor_lgbm":
    # DEMO_MODE 在无 GM 或显式环境变量时开启，保证本地可跑通
    demo = (not HAS_GM) or os.getenv("MFL_DEMO", "").lower() in ("1", "true", "yes")
    strat = MultiFactorLightGBMStrategy(demo=demo)
elif ACTIVE_STRATEGY == "multi_factor_magic9_experimental":
    demo = (not HAS_GM) or os.getenv("MFL_DEMO", "").lower() in ("1", "true", "yes")
    strat = MultiFactorMagicNineExperimentalStrategy(
        demo=demo,
        require_perfected=False,
        signal_max_age=2,
        entry_score_min=0.65,
        cooldown_days=3,
        require_bounce=True,
        require_volume=True,
    )
elif ACTIVE_STRATEGY == "default_v5":
    strat = DefaultStrategy()
else:
    strat = MagicNineStrategy(
        require_perfected=False,
        signal_max_age=2,
        entry_score_min=0.65,
        cooldown_days=3,
        require_bounce=True,
        require_volume=True,
    )

registry.register(
    strategy=strat,
    sl=ATRStructureSL(),
    tp=TrailPartialTP(),
    risk=PortfolioDDRisk(),
)


def _load_select():
    d = os.path.join(os.path.dirname(os.path.abspath(__file__)), "select")
    spec = importlib.util.spec_from_file_location(
        "v5_select", os.path.join(d, "__init__.py"), submodule_search_locations=[d])
    m = importlib.util.module_from_spec(spec)
    sys.modules["v5_select"] = m
    spec.loader.exec_module(m)
    return m


SELECT = _load_select()
INDEX_SYMBOL = getattr(SELECT, "INDEX_SYMBOL", config.INDEX_SYMBOL)


def _get(o, k, default=None):
    return o.get(k, default) if isinstance(o, dict) else getattr(o, k, default)


def _symbols_from_rows(raw):
    if isinstance(raw, pd.DataFrame):
        if "symbol" not in raw.columns:
            return []
        return sorted(raw["symbol"].astype(str).tolist())
    return sorted(str(_get(x, "symbol", x)) for x in (raw or []))


def _load_all_a_pool():
    attempts = [
        dict(exchanges="SHSE,SZSE", sec_types=1, fields="symbol", df=True),
        dict(exchange="SHSE,SZSE", sec_type=1, fields="symbol", df=True),
        dict(symbols=None, exchanges="SHSE,SZSE", sec_types=1, fields="symbol", df=True),
    ]
    for kwargs in attempts:
        try:
            raw = get_instruments(**kwargs)
            pool = [x for x in _symbols_from_rows(raw) if "." in str(x)]
            if pool:
                return pool
        except Exception:
            continue
    return []


def init(context):
    bt.validate_date_range()
    if HAS_GM:
        from broker import GM3Broker
        from strategy.state import PositionState
        context.broker = GM3Broker(context)
        context.state = PositionState()
    else:
        context.broker = None
        context.state = None
    context.today = None
    context.turnover_value = 0.0
    context.stock_pool = []
    context.trading_dates_sorted = []
    context.high_water = float(config.INIT_CAPITAL)
    context.risk_lock = False
    context.last_dd = 0.0
    context._select_mod = SELECT

    if HAS_GM:
        if ACTIVE_STRATEGY in ("multi_factor_lgbm", "multi_factor_magic9_experimental"):
            context.stock_pool = _load_all_a_pool()
            if context.stock_pool:
                print("UNIVERSE | all_a | n=%d" % len(context.stock_pool))
            else:
                print("WARN UNIVERSE | all_a unavailable, fallback to index constituents; long backtests may have constituent/survivorship bias")
        if not context.stock_pool:
            try:
                raw = stk_get_index_constituents(index=INDEX_SYMBOL)
            except Exception:
                raw = get_constituents(index=INDEX_SYMBOL)
            context.stock_pool = _symbols_from_rows(raw)
        context.stock_pool = [x for x in context.stock_pool if "." in str(x)]
        if not context.stock_pool:
            raise RuntimeError("stock_pool 为空")

        subscribe(symbols=context.stock_pool, frequency="1d", count=160,
                  fields="symbol,open,close,high,low,volume", unsubscribe_previous=True)
        subscribe(symbols=[INDEX_SYMBOL], frequency="1d", count=160,
                  fields="symbol,open,close,high,low,volume", unsubscribe_previous=False)
        schedule(schedule_func=algo, date_rule="1d", time_rule="14:50:00")

    registry.get_strategy().on_init(context)

    print("V6.3 INIT | pool=%d | capital=%.0f | start=%s | end=%s | strategy=%s | plugins=%s/%s/%s/%s" % (
        len(getattr(context, "stock_pool", []) or []), config.INIT_CAPITAL, bt.START, bt.END,
        registry.get_strategy().NAME,
        registry.get_strategy().NAME, registry.get_sl().NAME,
        registry.get_tp().NAME, registry.get_risk().NAME))


def algo(context):
    registry.get_strategy().on_bar(context)


def on_order_status(context, order):
    if not HAS_GM:
        return
    status = _get(order, "status")
    if status == OrderStatus_Filled:
        print("FILL | %s | %s | %s | volume=%s | price=%s" % (
            context.now, _get(order, "symbol"), _get(order, "side"),
            _get(order, "filled_volume", _get(order, "volume", 0)), _get(order, "price", 0)))
    elif status in (OrderStatus_Canceled, OrderStatus_Rejected, OrderStatus_Expired):
        print("ORDER FAIL | %s | status=%s | reason=%s" % (
            _get(order, "symbol"), status, _get(order, "ord_rej_reason_detail", "")))
    strat = registry.STRATEGY
    if strat is not None and hasattr(strat, "on_order_status"):
        strat.on_order_status(context, order)


def on_backtest_finished(context, indicator):
    print("V6.3 BACKTEST FINISHED | %s" % indicator)
    strat = registry.STRATEGY
    if strat is not None and hasattr(strat, "on_backtest_finished"):
        strat.on_backtest_finished(context, indicator)


def run_demo():
    """无 GM 环境下本地跑通：因子 → 训练 → 预测 → Top50 输出。"""
    print("=" * 60)
    print("MULTI_FACTOR_LGBM DEMO MODE (no gm.api)")
    print("=" * 60)
    class Ctx:
        pass
    ctx = Ctx()
    init(ctx)
    strat = registry.get_strategy()
    # 推进到 OOS 区间并输出调仓信号
    dates = getattr(ctx, "demo_dates", [])
    # 从 2013 年附近开始
    start_i = 0
    for i, d in enumerate(dates):
        if d.year >= 2013:
            start_i = i
            break
    ctx.demo_idx = start_i
    steps = min(len(dates) - start_i, 80)
    for _ in range(steps):
        strat.on_bar(ctx)
    print("-" * 60)
    print("Recent signals (last 5 rebalance days):")
    items = list(strat.signal_cache.items())[-5:]
    for d, tops in items:
        print("  %s -> Top50[:10]=%s" % (d, tops[:10]))
    print("-" * 60)
    print("Trained years:", sorted(strat._trained_years))
    print("Factor count:", len(strat.factor_names))
    print("DEMO DONE")
    return strat


if __name__ == "__main__":
    bt.validate_date_range()
    if not HAS_GM or os.getenv("MFL_DEMO", "").lower() in ("1", "true", "yes"):
        run_demo()
    else:
        run(strategy_id="369c6d83-93ec-11f1-a505-00ffaabbccdd", filename="main.py",
            mode=MODE_BACKTEST, token=config.GM_TOKEN,
            backtest_start_time=bt.START + " 09:00:00",
            backtest_end_time=bt.END + " 15:00:00",
            backtest_adjust=ADJUST_PREV,
            backtest_initial_cash=config.INIT_CAPITAL,
            backtest_commission_ratio=config.COMMISSION_RATIO,
            backtest_slippage_ratio=config.SLIPPAGE_RATIO,
            backtest_match_mode=config.BACKTEST_MATCH_MODE)
