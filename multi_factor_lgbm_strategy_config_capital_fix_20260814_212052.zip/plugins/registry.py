# -*- coding: utf-8 -*-
"""Central plugin registry. main.py registers implementations once at import time.
Supports optional auto-scan of plugins/*/plugin.yaml for dynamic discovery.
"""
from __future__ import annotations

import importlib
import os
from typing import Any, Dict, Optional

STRATEGY = None
STOP_LOSS = None
TAKE_PROFIT = None
RISK = None

# 动态发现的插件元数据 name -> meta
_DISCOVERED: Dict[str, Dict[str, Any]] = {}


def register(strategy=None, sl=None, tp=None, risk=None):
    """Register plugin instances. Pass only the slots you want to set."""
    global STRATEGY, STOP_LOSS, TAKE_PROFIT, RISK
    if strategy is not None:
        STRATEGY = strategy
    if sl is not None:
        STOP_LOSS = sl
    if tp is not None:
        TAKE_PROFIT = tp
    if risk is not None:
        RISK = risk


def get_strategy():
    if STRATEGY is None:
        raise RuntimeError("Strategy plugin not registered")
    return STRATEGY


def get_sl():
    if STOP_LOSS is None:
        raise RuntimeError("StopLoss plugin not registered")
    return STOP_LOSS


def get_tp():
    if TAKE_PROFIT is None:
        raise RuntimeError("TakeProfit plugin not registered")
    return TAKE_PROFIT


def get_risk():
    if RISK is None:
        raise RuntimeError("RiskControl plugin not registered")
    return RISK


def discover_plugins(plugins_root: Optional[str] = None) -> Dict[str, Dict[str, Any]]:
    """
    扫描 plugins/ 下各子目录的 plugin.yaml，返回 name -> meta。
    不自动实例化，仅发现；由 main 或调用方决定是否加载。
    """
    global _DISCOVERED
    if plugins_root is None:
        plugins_root = os.path.dirname(os.path.abspath(__file__))
    found = {}
    for dirpath, dirnames, filenames in os.walk(plugins_root):
        if "plugin.yaml" not in filenames and "plugin.yml" not in filenames:
            continue
        yaml_name = "plugin.yaml" if "plugin.yaml" in filenames else "plugin.yml"
        path = os.path.join(dirpath, yaml_name)
        try:
            meta = _parse_simple_yaml(path)
            name = meta.get("name") or os.path.basename(dirpath)
            meta["_path"] = dirpath
            meta["_yaml"] = path
            found[name] = meta
        except Exception as e:
            print("WARN discover plugin %s | %s" % (path, e))
    _DISCOVERED = found
    return found


def _parse_simple_yaml(path: str) -> Dict[str, Any]:
    """极简 YAML 解析（仅支持本项目 plugin.yaml 的扁平/浅层结构，无第三方依赖）。"""
    meta: Dict[str, Any] = {}
    with open(path, "r", encoding="utf-8") as f:
        lines = f.readlines()
    current_list_key = None
    for raw in lines:
        line = raw.rstrip()
        if not line or line.lstrip().startswith("#"):
            continue
        if line.strip().startswith("- "):
            val = line.strip()[2:].strip().strip('"').strip("'")
            if current_list_key:
                meta.setdefault(current_list_key, []).append(val)
            continue
        if ":" not in line:
            continue
        key, _, rest = line.partition(":")
        key = key.strip()
        rest = rest.strip()
        if not rest:
            current_list_key = key
            meta[key] = meta.get(key) or []
            continue
        current_list_key = None
        if (rest.startswith('"') and rest.endswith('"')) or (rest.startswith("'") and rest.endswith("'")):
            rest = rest[1:-1]
        try:
            if "." in rest:
                meta[key] = float(rest)
            else:
                meta[key] = int(rest)
        except ValueError:
            meta[key] = rest
    return meta


def load_strategy_from_discovered(name: str, **kwargs) -> Any:
    """根据 discover 结果实例化策略。"""
    if not _DISCOVERED:
        discover_plugins()
    meta = _DISCOVERED.get(name)
    if not meta:
        raise KeyError("plugin not found: %s (known=%s)" % (name, list(_DISCOVERED.keys())))
    if name == "multi_factor_lgbm":
        from plugins.strategy.multi_factor_lgbm import MultiFactorLightGBMStrategy
        return MultiFactorLightGBMStrategy(**kwargs)
    entry = meta.get("entry") or ""
    if ":" not in entry:
        raise ValueError("invalid entry for %s: %s" % (name, entry))
    mod_name, cls_name = entry.split(":", 1)
    rel = os.path.relpath(meta["_path"], os.path.dirname(os.path.abspath(__file__)))
    pkg = "plugins." + rel.replace(os.sep, ".")
    full_mod = pkg + "." + mod_name if mod_name else pkg
    mod = importlib.import_module(full_mod)
    cls = getattr(mod, cls_name)
    return cls(**kwargs)
