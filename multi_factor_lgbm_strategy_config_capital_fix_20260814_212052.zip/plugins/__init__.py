# -*- coding: utf-8 -*-
"""Plugin package: strategy / stop-loss / take-profit / risk-control."""
from . import registry

__all__ = ["registry"]
