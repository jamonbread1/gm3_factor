# -*- coding: utf-8 -*-
"""Default daily strategy: select -> dynamic size -> enter; SL/TP/Risk via plugins."""
import datetime
import numpy as np
import pandas as pd
import config
from plugins import registry
from strategy.portfolio import capital_profile, target_value
from strategy.lot_rules import min_lot_size


def _gm():
    from gm.api import get_history_instruments, get_instruments, get_trading_dates
    return get_history_instruments, get_instruments, get_trading_dates


def _get(o, k, default=None):
    return o.get(k, default) if isinstance(o, dict) else getattr(o, k, default)


def _sec_level(row):
    value = _get(row, "sec_level", 1)
    try:
        return int(value)
    except (TypeError, ValueError):
        return 99


def is_st_stock(symbol, trade_date=None):
    if trade_date is None:
        trade_date = datetime.date.today().strftime("%Y-%m-%d")
    try:
        get_history_instruments, _, _ = _gm()
        rows = get_history_instruments(
            symbols=[symbol],
            start_date=trade_date,
            end_date=trade_date,
            fields="symbol,sec_level,is_suspended,created_at",
            df=True,
        )
        if rows is None or len(rows) == 0:
            return True
        level = _sec_level(rows.iloc[-1])
        return level in (2, 3, 12, 13)
    except Exception as e:
        print("WARN ST CHECK | %s | date=%s | %s" % (symbol, trade_date, e))
        return True


def get_ma(context, symbol, period):
    try:
        d = context.broker.history(symbol, period, "close")
        return float(d["close"].astype(float).values[-period:].mean()) if d is not None and len(d) >= period else None
    except Exception:
        return None


def get_atr(context, symbol):
    try:
        d = context.broker.history(symbol, config.ATR_BARS, "close,high,low")
        if d is None or len(d) < config.ATR_PERIOD + 1:
            return None
        c = d["close"].astype(float).values
        h = d["high"].astype(float).values
        l = d["low"].astype(float).values
        tr = np.maximum(h[1:] - l[1:], np.maximum(abs(h[1:] - c[:-1]), abs(l[1:] - c[:-1])))
        return float(tr[-config.ATR_PERIOD:].mean())
    except Exception:
        return None


class DefaultStrategy:
    NAME = "default_v5"

    def on_init(self, context):
        pass

    def on_bar(self, context):
        import backtest_config as bt

        get_history_instruments, get_instruments, get_trading_dates = _gm()

        SELECT = getattr(context, "_select_mod", None)
        if SELECT is None or not hasattr(SELECT, "get_strong_stocks"):
            print("ERR | select module not attached on context._select_mod")
            return

        today = context.now.date()
        start = datetime.datetime.strptime(bt.START, "%Y-%m-%d").date()
        end = datetime.datetime.strptime(bt.END, "%Y-%m-%d").date()
        if today < start or today > end:
            return
        if context.today != today:
            context.today = today
            context.turnover_value = 0.0
        try:
            context.trading_dates_sorted = sorted(
                pd.Timestamp(x).date()
                for x in get_trading_dates(exchange="SHSE", start_date=bt.START, end_date=bt.END)
            )
        except Exception:
            pass

        risk = registry.get_risk()
        sl = registry.get_sl()
        tp = registry.get_tp()

        positions = context.broker.positions()
        context.state.reconcile(positions, today)
        total_asset = context.broker.total_asset()
        if total_asset <= 0:
            return

        profile = capital_profile(total_asset)
        context.capital_profile = profile

        risk_mult = risk.on_nav(context, total_asset)
        print("RISK | date=%s | nav=%.0f | tier=%s | dd=%.2f%% | lock=%s | mult=%.2f | max_pos=%d | slot=%.0f%%" % (
            today, total_asset, profile["tier"], context.last_dd * 100, context.risk_lock,
            risk_mult, profile["max_position_stock"], profile["max_position_pct"] * 100))

        for p in list(positions):
            symbol = p["symbol"]
            if is_st_stock(symbol, today.strftime("%Y-%m-%d")):
                try:
                    context.broker.sell_all(symbol)
                    context.turnover_value += context.broker.market_price(symbol) * int(p.get("volume", 0))
                    print("ST SELL | %s | date=%s" % (symbol, today))
                except Exception as e:
                    print("ERR ST SELL | %s | %s" % (symbol, e))
        positions = context.broker.positions()

        if risk.is_locked(context):
            if positions and context.last_dd >= config.PORTFOLIO_DD_STOP:
                for p in positions:
                    try:
                        context.broker.sell_all(p["symbol"])
                        context.turnover_value += context.broker.market_price(p["symbol"]) * int(p.get("volume", 0))
                        print("RISK SELL | %s | portfolio_dd=%.2f%%" % (p["symbol"], context.last_dd * 100))
                    except Exception as e:
                        print("ERR RISK SELL | %s | %s" % (p["symbol"], e))
            if risk.try_unlock(context):
                print("RISK UNLOCK | benchmark trend recovered")
            else:
                print("RISK LOCK | no new positions")
                return

        for p in positions:
            symbol = p["symbol"]
            price = context.broker.market_price(symbol)
            st = context.state.get(symbol)
            if not st or price <= 0:
                continue
            st["highest"] = max(float(st.get("highest", price)), price)
            atr = get_atr(context, symbol)
            ma20 = get_ma(context, symbol, config.MA_LONG)
            held = context.state.held_days(symbol, today, context.trading_dates_sorted)

            exit_sl, reasons_sl = sl.check(
                price, float(st.get("entry_price", price)), float(st.get("highest", price)),
                atr=atr, ma20=ma20, structure_stop=st.get("structure_stop"),
                held_days=held, symbol=symbol)
            full_tp, partial_tp, reasons_tp = tp.check(
                price, float(st.get("entry_price", price)), float(st.get("highest", price)),
                already_partial=bool(st.get("partial_done", False)), symbol=symbol, held_days=held)

            if exit_sl or full_tp:
                reasons = list(reasons_sl) + list(reasons_tp)
                try:
                    context.broker.sell_all(symbol)
                    context.turnover_value += price * int(p.get("volume", 0))
                    print("SELL | %s | %.2f | %s" % (symbol, price, ",".join(reasons)))
                except Exception as e:
                    print("ERR SELL | %s | %s" % (symbol, e))
            elif partial_tp:
                vol = int(p.get("volume", 0))
                lot_p = min_lot_size(symbol, profile["lot_size"])
                sell_vol = int(vol * tp.partial_ratio() / lot_p) * lot_p
                if sell_vol >= lot_p:
                    try:
                        context.broker.sell_volume(symbol, sell_vol)
                        context.turnover_value += price * sell_vol
                        st["partial_done"] = True
                        print("PARTIAL TP | %s | %.2f | vol=%d | %s" % (
                            symbol, price, sell_vol, ",".join(reasons_tp)))
                    except Exception as e:
                        print("ERR PARTIAL | %s | %s" % (symbol, e))

        held_positions = context.broker.positions()
        held = {p["symbol"] for p in held_positions if int(p.get("volume", 0)) > 0}
        gross = sum(float(p.get("amount", 0) or 0) for p in held_positions if int(p.get("volume", 0)) > 0)
        cash = context.broker.cash()
        if cash < total_asset * profile["min_cash_reserve_pct"] or risk_mult <= 0:
            return
        if len(held) >= profile["max_position_stock"]:
            return

        candidates = SELECT.get_strong_stocks(context, today, total_asset)
        if not candidates:
            print("NO SIGNAL | date=%s | pool=%d" % (today, len(context.stock_pool)))
            return

        buys = 0
        regime_mult = risk.regime_multiplier(context)
        effective_mult = regime_mult * risk_mult
        gross_cap = total_asset * profile["max_position_pct"] * profile["max_position_stock"]
        for symbol, score, detail in candidates:
            if buys >= profile["max_daily_buy"] or symbol in held:
                continue
            if len(held) >= profile["max_position_stock"]:
                break
            if context.turnover_value >= total_asset * profile["turnover_cap"]:
                break
            if gross >= gross_cap:
                break
            if float(score) < profile["min_buy_score"]:
                continue
            if is_st_stock(symbol, today.strftime("%Y-%m-%d")):
                print("ST SKIP | %s | date=%s" % (symbol, today))
                continue
            try:
                price = context.broker.market_price(symbol)
                ins = get_instruments(symbols=symbol, skip_suspended=True, skip_st=True)
            except Exception:
                continue
            if price <= 0 or not ins:
                continue
            room = max(0.0, gross_cap - gross)
            lot = min_lot_size(symbol, profile["lot_size"])
            value = target_value(
                total_asset, float(score), effective_mult, price,
                get_atr(context, symbol), cash, context.turnover_value,
                gross_room=room, profile=profile, symbol=symbol, lot_size=lot)
            shares = int(value / price / lot) * lot
            if shares < lot:
                continue
            try:
                context.broker.buy(symbol, shares)
                context.turnover_value += shares * price
                cash -= shares * price
                gross += shares * price
                held.add(symbol)
                buys += 1
                hist = None
                try:
                    hist = context.broker.history(symbol, config.STRUCT_STOP_LOOKBACK + 5, "low")
                except Exception:
                    pass
                context.state.items[symbol] = {
                    "entry_date": today,
                    "entry_price": price,
                    "highest": price,
                    "partial_done": False,
                    "structure_stop": sl.calc_structure_stop(hist),
                }
                print("BUY | %s | score=%.3f | regime=%.2f | risk=%.2f | shares=%d | price=%.2f | %s" % (
                    symbol, score, regime_mult, risk_mult, shares, price, detail))
            except Exception as e:
                print("ERR BUY | %s | %s | no position opened" % (symbol, e))

    def on_order_status(self, context, order):
        pass

    def on_backtest_finished(self, context, indicator):
        pass
