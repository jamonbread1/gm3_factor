# Strategy 插件接口规范

## 职责

- 每日选股、下单、持仓管理的主逻辑
- 调用 Factor / SL / TP / Risk 插件，自身不实现止损/止盈/风控细节
- 不直接依赖 gm.api 交易函数，统一通过 `context.broker`

## 必须实现的接口

```python
class BaseStrategy:
    NAME: str = "..."

    def on_init(self, context) -> None:
        """init() 阶段调用一次。可订阅额外标的、写 context 状态。"""

    def on_bar(self, context) -> None:
        """每个交易日 schedule 触发时调用（当前 14:50）。
        context 保证已有:
          - context.broker: GM3Broker
          - context.state: PositionState
          - context.stock_pool: list[str]
          - context.today: date
          - context.turnover_value: float
          - context.trading_dates_sorted: list[date]
          - context.high_water / context.risk_lock / context.last_dd
        """
```

## 内置实现

| 类 | NAME | 说明 |
|----|------|------|
| `DefaultStrategy` | `default_v5` | 因子选股 + 动态仓位 |
| `MagicNineStrategy` | `magic_nine` | TD 九转买结构 + 多周期趋势过滤（无未来函数） |
| `MultiFactorLightGBMStrategy` | `multi_factor_lgbm` | 多因子排名选股 |
| `MultiFactorMagicNineExperimentalStrategy` | `multi_factor_magic9_experimental` | 多因子选股 + 九转风控实验策略 |

### Magic Nine 要点

- 信号只基于 `strategy.data_guard.closed_daily_data` 的**已收盘**日 K
- 买：连续 9 根 `close < close[i-4]`，且在 `signal_max_age` 根内
- 趋势：MA20/60/120 多尺度 + 相对指数超额；熊市默认不开新仓
- 过滤：ST、流动性、ATR、放量崩跌、卖九转冲突
- 仓位：走 `capital_profile` / `target_value`；出场走 SL/TP 插件

注册示例：

```python
from plugins.strategy.magic_nine import MagicNineStrategy
registry.register(strategy=MagicNineStrategy(), sl=..., tp=..., risk=...)
```

## 可选扩展钩子

```python
    def on_order_status(self, context, order) -> None: ...
    def on_backtest_finished(self, context, indicator) -> None: ...
    def before_entries(self, context, candidates) -> list: ...
    def after_exit(self, context, symbol, reasons) -> None: ...
```

## 兼容性

- 必须兼容 GM3 `schedule(..., time_rule='14:50:00')`
- 回测 `init` 内禁止下单
- 所有下单走 `context.broker.buy / sell_all / sell_volume`
- **禁止未来函数**：不得使用当日未收盘 bar 的 OHLC 做信号计数

## MultiFactorLightGBMStrategy

见 `plugins/strategy/multi_factor_lgbm/rule.md`。

注册：
```python
from plugins.strategy.multi_factor_lgbm import MultiFactorLightGBMStrategy
registry.register(strategy=MultiFactorLightGBMStrategy(), ...)
# 或环境变量 ACTIVE_STRATEGY=multi_factor_lgbm
```
