# -*- coding: utf-8 -*-
"""
72+ 因子计算模块（pandas 向量化）。全部输入 LightGBM，不做筛选/降维。
"""
from __future__ import annotations

import warnings
import numpy as np
import pandas as pd
from typing import List

warnings.filterwarnings("ignore", message="Mean of empty slice", category=RuntimeWarning)

FACTOR_NAMES: List[str] = []


def compute_all_factors(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or len(df) < 30:
        return pd.DataFrame()

    o = df["open"].astype(float)
    h = df["high"].astype(float)
    l = df["low"].astype(float)
    c = df["close"].astype(float)
    v = df["volume"].astype(float)
    if "amount" in df.columns:
        amt = df["amount"].astype(float)
    else:
        amt = c * v

    r1 = c.pct_change(1)
    factors = {}

    for lag in [1, 3, 5, 10, 15, 20, 30, 60, 120]:
        factors["mom_%dd" % lag] = c.pct_change(lag)
    factors["mom_5_20"] = factors["mom_5d"] - factors["mom_20d"]
    factors["mom_20_60"] = factors["mom_20d"] - factors["mom_60d"]
    factors["mom_60_120"] = factors["mom_60d"] - factors["mom_120d"]
    ma20 = c.rolling(20).mean()
    ma60 = c.rolling(60).mean()
    ma120 = c.rolling(120).mean()
    factors["price_to_ma20"] = c / ma20 - 1
    factors["price_to_ma60"] = c / ma60 - 1
    factors["price_to_ma120"] = c / ma120 - 1
    factors["high_20_pos"] = (c - c.rolling(20).min()) / (c.rolling(20).max() - c.rolling(20).min() + 1e-12)
    factors["high_60_pos"] = (c - c.rolling(60).min()) / (c.rolling(60).max() - c.rolling(60).min() + 1e-12)
    factors["close_to_high20"] = c / c.rolling(20).max() - 1
    factors["close_to_low20"] = c / c.rolling(20).min() - 1

    for lag in [1, 3, 5, 10, 20]:
        factors["rev_%dd" % lag] = -c.pct_change(lag)
    factors["overnight_ret"] = o / c.shift(1) - 1
    factors["intraday_ret"] = c / o - 1
    factors["max_drawdown_20"] = c / c.rolling(20).max() - 1
    factors["max_drawdown_60"] = c / c.rolling(60).max() - 1

    factors["vol_5d"] = r1.rolling(5).std()
    factors["vol_10d"] = r1.rolling(10).std()
    factors["vol_20d"] = r1.rolling(20).std()
    factors["vol_60d"] = r1.rolling(60).std()
    factors["vol_ratio_5_20"] = factors["vol_5d"] / (factors["vol_20d"] + 1e-12)
    factors["vol_ratio_20_60"] = factors["vol_20d"] / (factors["vol_60d"] + 1e-12)
    log_hl = np.log((h / l).clip(lower=1e-6))
    factors["parkinson_20"] = (log_hl ** 2).rolling(20).mean() ** 0.5
    factors["parkinson_60"] = (log_hl ** 2).rolling(60).mean() ** 0.5
    up = r1.clip(lower=0)
    dn = (-r1).clip(lower=0)
    factors["up_vol_20"] = up.rolling(20).mean()
    factors["dn_vol_20"] = dn.rolling(20).mean()
    factors["vol_asym_20"] = factors["up_vol_20"] / (factors["dn_vol_20"] + 1e-12)

    v_ma20 = v.rolling(20).mean()
    v_ma60 = v.rolling(60).mean()
    amt_ma20 = amt.rolling(20).mean()
    amt_ma60 = amt.rolling(60).mean()
    factors["turn_1d"] = v / (v_ma20 + 1e-12)
    factors["turn_5d"] = v.rolling(5).mean() / (v_ma20 + 1e-12)
    factors["turn_20d"] = v_ma20 / (v_ma60 + 1e-12)
    factors["amt_1d"] = amt / (amt_ma20 + 1e-12)
    factors["amt_5d"] = amt.rolling(5).mean() / (amt_ma20 + 1e-12)
    factors["amt_20d"] = amt_ma20 / (amt_ma60 + 1e-12)
    factors["vol_ma5_ma20"] = v.rolling(5).mean() / (v_ma20 + 1e-12)
    factors["vol_ma20_ma60"] = v_ma20 / (v_ma60 + 1e-12)
    factors["amt_std_20"] = amt.rolling(20).std()
    factors["vol_std_20"] = v.rolling(20).std()
    factors["corr_price_vol_20"] = c.rolling(20).corr(v)
    factors["corr_ret_vol_20"] = r1.rolling(20).corr(v)
    factors["volume_spike"] = v / (v_ma20 + 1e-12)
    factors["amount_spike"] = amt / (amt_ma20 + 1e-12)

    def rsi(series, period):
        delta = series.diff()
        gain = delta.clip(lower=0).rolling(period).mean()
        loss = (-delta.clip(upper=0)).rolling(period).mean()
        rs = gain / (loss + 1e-12)
        return 100 - 100 / (1 + rs)

    factors["rsi_6"] = rsi(c, 6)
    factors["rsi_14"] = rsi(c, 14)
    factors["rsi_24"] = rsi(c, 24)

    ema12 = c.ewm(span=12, adjust=False).mean()
    ema26 = c.ewm(span=26, adjust=False).mean()
    dif = ema12 - ema26
    dea = dif.ewm(span=9, adjust=False).mean()
    factors["macd_dif"] = dif
    factors["macd_dea"] = dea
    factors["macd_hist"] = dif - dea

    std20 = c.rolling(20).std()
    factors["bb_pos"] = (c - (ma20 - 2 * std20)) / (4 * std20 + 1e-12)
    factors["bb_width"] = (4 * std20) / (ma20 + 1e-12)

    prev_c = c.shift(1)
    tr = pd.concat([h - l, (h - prev_c).abs(), (l - prev_c).abs()], axis=1).max(axis=1)
    factors["atr_14"] = tr.rolling(14).mean()
    factors["atr_pct"] = factors["atr_14"] / c

    lowest9 = l.rolling(9).min()
    highest9 = h.rolling(9).max()
    rsv = (c - lowest9) / (highest9 - lowest9 + 1e-12) * 100
    factors["kdj_k"] = rsv.ewm(com=2, adjust=False).mean()
    factors["kdj_d"] = factors["kdj_k"].ewm(com=2, adjust=False).mean()
    factors["kdj_j"] = 3 * factors["kdj_k"] - 2 * factors["kdj_d"]

    tp = (h + l + c) / 3
    factors["cci_14"] = (tp - tp.rolling(14).mean()) / (0.015 * tp.rolling(14).std() + 1e-12)
    factors["willr_14"] = (h.rolling(14).max() - c) / (h.rolling(14).max() - l.rolling(14).min() + 1e-12) * -100

    # rank 用百分位加速：用 (x - min) / (max - min)
    factors["price_pct_rank_60"] = (c - c.rolling(60).min()) / (c.rolling(60).max() - c.rolling(60).min() + 1e-12)
    factors["price_pct_rank_120"] = (c - c.rolling(120).min()) / (c.rolling(120).max() - c.rolling(120).min() + 1e-12)
    factors["amt_pct_rank_60"] = (amt - amt.rolling(60).min()) / (amt.rolling(60).max() - amt.rolling(60).min() + 1e-12)
    factors["log_price"] = np.log(c.clip(lower=1e-6))
    factors["log_amt"] = np.log(amt.clip(lower=1.0))
    factors["pseudo_mcap"] = np.log(amt_ma20.clip(lower=1.0))
    factors["pseudo_mcap_chg"] = amt_ma20.pct_change(20)

    factors["high_low_range"] = (h - l) / c
    factors["high_low_range_20"] = factors["high_low_range"].rolling(20).mean()
    factors["gap"] = o / c.shift(1) - 1
    factors["gap_abs_20"] = factors["gap"].abs().rolling(20).mean()
    factors["downside_vol_20"] = dn.rolling(20).mean()
    factors["upside_vol_20"] = up.rolling(20).mean()
    factors["skew_20"] = r1.rolling(20).skew()
    factors["kurt_20"] = r1.rolling(20).kurt()
    factors["auto_corr_5"] = r1.rolling(5).corr(r1.shift(1))
    factors["auto_corr_20"] = r1.rolling(20).corr(r1.shift(1))
    factors["trend_strength_20"] = factors["mom_20d"] / (factors["vol_20d"] * np.sqrt(20) + 1e-12)
    factors["trend_strength_60"] = factors["mom_60d"] / (factors["vol_60d"] * np.sqrt(60) + 1e-12)

    global FACTOR_NAMES
    if not FACTOR_NAMES:
        FACTOR_NAMES = sorted(factors.keys())

    out = pd.DataFrame({k: factors[k] for k in FACTOR_NAMES if k in factors})
    out.index = df.index
    return out


def get_factor_names() -> List[str]:
    if not FACTOR_NAMES:
        dummy = pd.DataFrame({
            "open": np.ones(30), "high": np.ones(30) * 1.01,
            "low": np.ones(30) * 0.99, "close": np.ones(30),
            "volume": np.ones(30) * 1e6,
        })
        compute_all_factors(dummy)
    return list(FACTOR_NAMES)


def mad_zscore(df: pd.DataFrame, n_mad: float = 5.0) -> pd.DataFrame:
    if df is None or df.empty:
        return df
    out = df.copy()
    for col in out.columns:
        s = pd.to_numeric(out[col], errors="coerce").replace([np.inf, -np.inf], np.nan)
        valid = s.dropna()
        if len(valid) < 2:
            out[col] = 0.0
            continue
        med = s.median()
        mad = (s - med).abs().median()
        if mad < 1e-12 or np.isnan(mad):
            out[col] = 0.0
            continue
        upper = med + n_mad * 1.4826 * mad
        lower = med - n_mad * 1.4826 * mad
        s = s.clip(lower, upper)
        mu = s.mean()
        sigma = s.std()
        if sigma < 1e-12 or np.isnan(sigma):
            out[col] = 0.0
        else:
            out[col] = (s - mu) / sigma
    return out.fillna(0.0)


def cross_section_rank_target(returns: pd.Series) -> pd.Series:
    if returns is None or len(returns) == 0:
        return returns
    return returns.rank(method="average", pct=True)
