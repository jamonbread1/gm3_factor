# -*- coding: utf-8 -*-
"""MultiFactor LightGBM 选股策略配置。严格遵循用户给定规则，不得擅自修改。"""

# ---- 选股与持仓 ----
HOLD_COUNT = 50                 # Top50
WEIGHT_PER_STOCK = 0.02         # 等权 2%
REBALANCE_DAYS = 5              # 每 5 个交易日调仓

# ---- 时间与滚动训练 ----
DATA_START = "2010-01-01"
OOS_START = "2013-01-01"
TRAIN_WINDOW = 756              # 约 3 年交易日
RETRAIN_FREQ_YEARS = 1          # 每年重训一次
TARGET_HORIZON = 5              # 未来 5 日收益 rank
TRADE_SHIFT = 2                 # T+2 执行修正
WALK_FORWARD = True             # True=每年 walk-forward；False=使用 OOS_DATA 训练静态模型
OOS_DATA = ""                   # WALK_FORWARD=False 时填写 "yyyy-mm-dd:yyyy-mm-dd"
ALLOW_STATIC_TRAIN_OVERLAP = False  # False=训练期内不交易；True=允许训练期内观察拟合内表现
MIN_TRAIN_ROWS = 500            # 训练样本不足时跳过，避免小样本硬训
MIN_TRAIN_DATES = 120           # 训练交易日不足时跳过，避免日期太少导致过拟合

# ---- 可交易过滤 ----
MIN_LIST_DAYS = 120             # 上市不足 120 天剔除
MIN_AVG_AMOUNT_20D = 5_000_000  # 20 日日均成交额 < 500 万剔除
EXCLUDE_ST = True
EXCLUDE_SUSPENDED = True        # 成交量为 0
LIMIT_UP_SKIP_BUY = True        # 开盘价 >= 涨停价 跳过买入
LIMIT_DOWN_HOLD = True          # 开盘价 <= 跌停价 维持持仓不卖

# ---- 因子预处理 ----
MAD_N = 5                       # MAD 去极值倍数
ZSCORE = True

# ---- LightGBM 默认参数 ----
LGBM_PARAMS = {
    "objective": "regression",
    "metric": "l2",
    "learning_rate": 0.03,
    "num_leaves": 31,
    "max_depth": 5,
    "feature_fraction": 0.8,
    "bagging_fraction": 0.8,
    "bagging_freq": 5,
    "lambda_l1": 0.1,
    "lambda_l2": 5.0,
    "min_data_in_leaf": 50,
    "verbosity": -1,
    "n_jobs": -1,
    "seed": 42,
}
LGBM_NUM_BOOST_ROUND = 50
LGBM_EARLY_STOPPING = 30

# ---- 模型存储 ----
MODEL_DIR = "models/multi_factor_lgbm"   # 相对项目根
MODEL_PREFIX = "model_"

# ---- 股票池 ----
# 全 A 股，运行时从 GM 获取或本地缓存；回测时过滤后约 3271 只
UNIVERSE = "all_a"
INDEX_SYMBOL = "SHSE.000300"            # 仅用于参考，非成分限制

# ---- 演示/本地模式 ----
# 当无 gm.api 或设置 DEMO_MODE=True 时，使用合成数据跑通全流程
DEMO_MODE = False
DEMO_N_STOCKS = 40
DEMO_N_DAYS = 1200
