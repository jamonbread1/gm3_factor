# -*- coding: utf-8 -*-
"""
LightGBM Rank / 回归模型：训练、保存、加载、预测。
支持 walk-forward 年度模型和非 walk-forward 静态模型。
模型保存为 pkl，是否复用由策略层校验训练窗口元信息决定。
"""
from __future__ import annotations

import os
import pickle
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from . import config as cfg
from .factors import get_factor_names, mad_zscore

try:
    import lightgbm as lgb
    HAS_LGBM = True
except ImportError:
    HAS_LGBM = False
    lgb = None


def _ensure_model_dir(root: str) -> str:
    path = os.path.join(root, cfg.MODEL_DIR)
    os.makedirs(path, exist_ok=True)
    return path


def model_path(root: str, year: int) -> str:
    d = _ensure_model_dir(root)
    return os.path.join(d, f"{cfg.MODEL_PREFIX}{year}.pkl")


def static_model_path(root: str) -> str:
    d = _ensure_model_dir(root)
    return os.path.join(d, "model_static.pkl")


def save_model(model: Any, path: str, meta: Optional[Dict] = None) -> None:
    payload = {"model": model, "meta": meta or {}, "factor_names": get_factor_names()}
    with open(path, "wb") as f:
        pickle.dump(payload, f, protocol=pickle.HIGHEST_PROTOCOL)


def load_model(path: str) -> Tuple[Any, Dict]:
    with open(path, "rb") as f:
        payload = pickle.load(f)
    return payload["model"], payload.get("meta", {})


def train_lgbm(
    X: pd.DataFrame,
    y: pd.Series,
    group: Optional[np.ndarray] = None,
    params: Optional[Dict] = None,
    num_boost_round: int = None,
) -> Any:
    """
    训练 LightGBM。优先 lambdarank（需 group），否则回归。
    X: 样本 x 因子, y: 目标 (rank 或收益)
    group: 每个交易日的样本数（lambdarank 需要）
    """
    if not HAS_LGBM:
        raise RuntimeError("lightgbm 未安装，请 pip install lightgbm")

    params = dict(params or cfg.LGBM_PARAMS)
    num_boost_round = num_boost_round or cfg.LGBM_NUM_BOOST_ROUND
    feature_names = list(X.columns)

    # 若无有效 group 或 group 全 1，退化为回归
    # 目标为连续 rank [0,1]，使用 regression 更稳定；若需 lambdarank 可将 y 转为 int 分档
    params["objective"] = "regression"
    params["metric"] = "l2"
    if "lambdarank" in str(params.get("objective", "")):
        params["objective"] = "regression"
    train_set = lgb.Dataset(X, label=y, feature_name=feature_names, free_raw_data=False)

    model = lgb.train(
        params,
        train_set,
        num_boost_round=num_boost_round,
        callbacks=[lgb.log_evaluation(period=0)],
    )
    return model


def predict(model: Any, X: pd.DataFrame) -> np.ndarray:
    if model is None:
        return np.zeros(len(X))
    return model.predict(X)


def prepare_train_matrix(
    panel: pd.DataFrame,
    feature_cols: List[str],
    target_col: str = "target",
    date_col: str = "date",
) -> Tuple[pd.DataFrame, pd.Series, np.ndarray]:
    """
    panel: 长表，含 date, symbol, 因子列, target
    返回 X, y, group（按 date 分组样本数，供 lambdarank）
    """
    df = panel.dropna(subset=feature_cols + [target_col]).copy()
    if df.empty:
        return pd.DataFrame(), pd.Series(dtype=float), np.array([])

    # 按日期排序，保证 group 连续
    df = df.sort_values([date_col, "symbol"]).reset_index(drop=True)
    X = df[feature_cols].astype(float)
    y = df[target_col].astype(float)
    groups = df.groupby(date_col, sort=False).size().values
    return X, y, groups


def walk_forward_years(oos_start_year: int = 2013, end_year: int = 2025) -> List[int]:
    """返回需要训练/预测的年份列表（OOS 年）"""
    return list(range(oos_start_year, end_year + 1))


def train_year_range(train_end_year: int, window_days: int = 756) -> Tuple[str, str]:
    """
    给定预测年份 train_end_year（即模型用于该年），
    训练数据约为 [train_end_year-3, train_end_year) 对应 756 交易日。
    返回 (start_date_str, end_date_str) 近似。
    """
    # 简化：日历年近似
    start_year = train_end_year - 3
    return f"{start_year}-01-01", f"{train_end_year - 1}-12-31"
