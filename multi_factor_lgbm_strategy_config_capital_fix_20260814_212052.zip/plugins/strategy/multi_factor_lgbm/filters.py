# -*- coding: utf-8 -*-
"""
可交易性过滤：严格按规则实现，避免未来函数。
- 剔除 ST/*ST
- 剔除上市不足 120 天次新股
- 剔除换仓日成交量为 0 的停牌
- 剔除 20 日日均成交额 < 500 万
- 开盘价 >= 涨停价 跳过买入
- 开盘价 <= 跌停价 维持原有持仓不卖出
"""
from __future__ import annotations

import datetime
from typing import Any, Dict, List, Optional, Set, Tuple

import numpy as np
import pandas as pd

from . import config as cfg


def _get(o, k, default=None):
    return o.get(k, default) if isinstance(o, dict) else getattr(o, k, default)


def is_st_stock(symbol: str, trade_date: str, gm_funcs=None) -> bool:
    """通过 sec_level 判断 ST。无法获取时保守返回 True（剔除）。"""
    if not cfg.EXCLUDE_ST:
        return False
    try:
        if gm_funcs is None:
            from gm.api import get_history_instruments
        else:
            get_history_instruments = gm_funcs[0]
        rows = get_history_instruments(
            symbols=[symbol],
            start_date=trade_date,
            end_date=trade_date,
            fields="symbol,sec_level,is_suspended,created_at",
            df=True,
        )
        if rows is None or len(rows) == 0:
            return True
        level = int(_get(rows.iloc[-1], "sec_level", 1) or 1)
        # 2/3/12/13 常见为 ST 相关
        return level in (2, 3, 12, 13)
    except Exception:
        # 名称含 ST 也剔除
        s = str(symbol).upper()
        return "ST" in s


def list_days(symbol: str, trade_date: str, gm_funcs=None) -> int:
    """上市天数。无法获取返回 0。"""
    try:
        if gm_funcs is None:
            from gm.api import get_instruments
        else:
            get_instruments = gm_funcs[1]
        info = get_instruments(symbols=symbol, df=True)
        if info is None or len(info) == 0:
            return 0
        created = _get(info.iloc[0], "listed_date") or _get(info.iloc[0], "created_at")
        if created is None:
            return 9999
        if hasattr(created, "date"):
            created = created.date()
        elif isinstance(created, str):
            created = datetime.datetime.strptime(created[:10], "%Y-%m-%d").date()
        td = datetime.datetime.strptime(trade_date[:10], "%Y-%m-%d").date()
        return (td - created).days
    except Exception:
        return 9999


def is_suspended_or_zero_vol(volume: float) -> bool:
    if not cfg.EXCLUDE_SUSPENDED:
        return False
    return volume is None or (isinstance(volume, float) and (np.isnan(volume) or volume <= 0))


def low_liquidity(avg_amount_20d: float) -> bool:
    if avg_amount_20d is None or np.isnan(avg_amount_20d):
        return True
    return avg_amount_20d < cfg.MIN_AVG_AMOUNT_20D


def calc_limit_prices(pre_close: float, is_st: bool = False) -> Tuple[float, float]:
    """
    前复权口径下的涨跌停价格近似。
    主板/创业板简化：普通 ±10%，ST ±5%。
    实际应以交易所规则 + 精确 tick 为准，此处用于过滤。
    """
    if pre_close is None or pre_close <= 0 or np.isnan(pre_close):
        return np.nan, np.nan
    pct = 0.05 if is_st else 0.10
    up = round(pre_close * (1 + pct), 2)
    down = round(pre_close * (1 - pct), 2)
    return up, down


def is_limit_up(open_price: float, pre_close: float, is_st: bool = False) -> bool:
    if not cfg.LIMIT_UP_SKIP_BUY:
        return False
    up, _ = calc_limit_prices(pre_close, is_st)
    if np.isnan(up) or open_price is None or np.isnan(open_price):
        return False
    return open_price >= up - 1e-6


def is_limit_down(open_price: float, pre_close: float, is_st: bool = False) -> bool:
    if not cfg.LIMIT_DOWN_HOLD:
        return False
    _, down = calc_limit_prices(pre_close, is_st)
    if np.isnan(down) or open_price is None or np.isnan(open_price):
        return False
    return open_price <= down + 1e-6


def filter_universe(
    candidates: List[str],
    trade_date: str,
    bar_map: Dict[str, Dict[str, float]],
    gm_funcs=None,
) -> List[str]:
    """
    对候选池做基础可交易过滤（不含涨跌停，涨跌停在下单时再判）。
    bar_map[symbol] = {volume, amount_20d_avg, pre_close, open, ...}
    """
    passed = []
    for sym in candidates:
        bar = bar_map.get(sym) or {}
        vol = bar.get("volume", 0)
        if is_suspended_or_zero_vol(vol):
            continue
        amt20 = bar.get("amount_20d_avg", bar.get("amount", 0))
        if low_liquidity(amt20):
            continue
        if is_st_stock(sym, trade_date, gm_funcs):
            continue
        days = list_days(sym, trade_date, gm_funcs)
        if days < cfg.MIN_LIST_DAYS:
            continue
        passed.append(sym)
    return passed


def apply_limit_rules(
    to_buy: List[str],
    to_sell: List[str],
    current_holdings: Set[str],
    bar_map: Dict[str, Dict[str, float]],
    st_map: Optional[Dict[str, bool]] = None,
) -> Tuple[List[str], List[str]]:
    """
    涨跌停处理：
    - 开盘价 >= 涨停价 的个股跳过不买入
    - 开盘价 <= 跌停价 的个股维持原有持仓不卖出
    """
    st_map = st_map or {}
    final_buy = []
    for sym in to_buy:
        bar = bar_map.get(sym) or {}
        open_p = bar.get("open")
        pre_c = bar.get("pre_close", bar.get("close"))
        st = st_map.get(sym, False)
        if is_limit_up(open_p, pre_c, st):
            continue
        final_buy.append(sym)

    final_sell = []
    for sym in to_sell:
        if sym not in current_holdings:
            continue
        bar = bar_map.get(sym) or {}
        open_p = bar.get("open")
        pre_c = bar.get("pre_close", bar.get("close"))
        st = st_map.get(sym, False)
        if is_limit_down(open_p, pre_c, st):
            # 跌停不卖，保留持仓
            continue
        final_sell.append(sym)
    return final_buy, final_sell
