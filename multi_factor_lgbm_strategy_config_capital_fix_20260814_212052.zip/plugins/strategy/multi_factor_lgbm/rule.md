# MultiFactor LightGBM 选股策略说明

## 一、策略定位

基于 **72+ 全量因子 + LightGBM Rank** 的截面选股策略，严格按既定回测口径实现：

- 选股池：全 A 股（过滤后约 3271 只）
- 持仓：固定 Top50，等权，单只 2%
- 调仓：每 5 个交易日
- 执行：信号日 t，实际成交 t+2（T+2 修正）
- 训练：默认 walk-forward，样本外从 2013 年起，每年只用上一年末以前的数据重训，预测当年
- 目标：未来 5 日收益的横截面 rank
- 标签：训练窗口末尾会裁掉 `TARGET_HORIZON` 个交易日，避免未来 5 日标签跨入下一年/OOS 区间
- **不做任何因子筛选、ICIR 过滤、相关性剔除**

## 二、因子体系

因子由 `factors.py` 统一计算，覆盖：

| 大类 | 数量级 | 示例 |
|------|--------|------|
| 动量 | ~16 | mom_1d/5d/20d/60d/120d, price_to_ma, high_pos |
| 反转 | ~8 | rev_1d/5d/20d, overnight, max_drawdown |
| 波动 | ~10 | vol_5/20/60, parkinson, vol_asym |
| 换手/成交量 | ~14 | turn, amt, vol_ma, corr_price_vol |
| 技术 | ~16 | RSI, MACD, BB, ATR, KDJ, CCI, WillR |
| 估值代理 | ~8 | price_pct_rank, log_amt, pseudo_mcap |
| 杠杆/结构 | ~6+ | high_low_range, gap, skew, kurt, trend_strength |

合计 **≥ 72**（当前实现约 88 个）。全部输入模型，预处理仅做 **MAD 去极值 + 截面 Z-score**。

## 三、模型

- 默认使用 `regression` 目标训练截面 rank 标签
- 参数见 `config.LGBM_PARAMS`：learning_rate=0.03, num_leaves=31, max_depth=5, feature_fraction=0.8, bagging_fraction=0.8, lambda_l1=0.1, lambda_l2=5
- walk-forward 模型文件：`models/multi_factor_lgbm/model_YYYY.pkl`
- 非 walk-forward 模型文件：`models/multi_factor_lgbm/model_static.pkl`
- 已存在 pkl 只有在元信息与当前训练窗口完全匹配时才加载；不会用上一年模型或 `latest.pkl` 代替新年份模型
- 当前版本不使用 OOS 区间做 early stopping；LightGBM 使用固定轮数训练

## 四、可交易过滤（严格执行）

1. 剔除 ST / *ST（sec_level 或名称）
2. 剔除上市不足 120 天次新股
3. 剔除换仓日成交量为 0 的停牌
4. 剔除 20 日日均成交额 < 500 万
5. 开盘价 ≥ 涨停价 → 跳过买入
6. 开盘价 ≤ 跌停价 → 维持持仓不卖出

涨跌停阈值按前收盘 ±10%（ST ±5%）近似，前复权口径。

## 五、T+2 执行

信号在调仓日 t 收盘后产生，写入 `context.mfl_pending[t+2]`，在 t+2 日 `on_bar` 开始时执行调仓，避免未来函数。

## 六、运行方式

### 1. 掘金 GM 环境（正式回测）

```bash
# 设置 token
export GM_TOKEN=你的token

# 修改 backtest_config.py 的 START/END
# 修改 main.py 注册为 MultiFactorLightGBMStrategy

python main.py
```

关闭 walk-forward 时，直接改 `config.py`：

```python
WALK_FORWARD = False
OOS_DATA = "2018-01-01:2020-12-31"
ALLOW_STATIC_TRAIN_OVERLAP = False
```

非 walk-forward 模式下，默认会先用 `OOS_DATA` 训练静态模型，然后从 `OOS_DATA` 结束日期之后开始出信号；如需观察训练期内表现，可把 `ALLOW_STATIC_TRAIN_OVERLAP` 设为 `True`。

### 2. 本地 Demo 模式（无 GM / 无数据时验证流程）

```bash
pip install lightgbm pandas numpy

# 在代码中设置 DEMO_MODE=True 或策略初始化 demo=True
python -c "
from plugins.strategy.multi_factor_lgbm import MultiFactorLightGBMStrategy
class Ctx: pass
ctx = Ctx()
s = MultiFactorLightGBMStrategy(demo=True)
s.on_init(ctx)
for _ in range(20):
    s.on_bar(ctx)
print('signals', list(s.signal_cache.items())[-3:])
"
```

首次训练会生成对应模型 pkl；之后只有配置与训练窗口完全一致时才加载。

## 七、实盘注意事项

1. **涨跌停与停牌** 必须以实盘行情接口实时判断，回测近似可能与实盘有差异。
2. **全 A 订阅** 数量大，注意 GM 配额与内存；可先用沪深300/中证500 做小规模验证。
3. **财务真因子**（PE/PB/ROE 等）需接入财务数据源；当前用价格与成交量代理，上线前建议替换。
4. **交易成本**：config 中 commission/slippage 需按实盘券商调整。
5. **模型衰减**：建议每年至少重训一次，并监控截面 IC / 分层收益。
6. **最大回撤**：历史参考约 -50%，需配合 risk 插件或仓位管理。

## 八、验收对照

- [x] 因子 ≥ 72，全量进模型，无筛选
- [x] 滚动训练：2013 用 2010-2012，2014 用 2011-2013，…（日历年近似 + 756 天窗口）
- [x] T+2 执行
- [x] ST/次新/流动性/涨跌停过滤
- [x] 模型 pkl 保存与加载
- [x] 插件独立，不破坏原有 registry 注册
- [x] rule.md 与配置完整

## 九、参考回测口径（非硬性）

- 年化约 18.82%，总收益约 810%，夏普约 0.68，最大回撤约 -50.05%
- 若结果偏离过大，优先检查：是否误用未来数据、过滤是否生效、T+2 是否落地、因子是否全量。
