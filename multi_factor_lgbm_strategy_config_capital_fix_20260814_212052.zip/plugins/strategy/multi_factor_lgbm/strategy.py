# -*- coding: utf-8 -*-
"""
MultiFactor LightGBM 选股策略主逻辑。
- 全 A 股池（过滤后）
- Top50 等权 2%
- 每 5 日调仓，T+2 执行
- 72+ 因子全量进 LightGBM Rank
- walk-forward 年度重训，或用 oos_data 指定静态训练集
- 严格可交易过滤 + 涨跌停处理
"""
from __future__ import annotations

import datetime
import os
from collections import defaultdict
from typing import Any, Dict, List, Optional, Set, Tuple

import numpy as np
import pandas as pd

import config as root_config
from plugins import registry
from strategy.portfolio import capital_profile, target_value
from strategy.lot_rules import min_lot_size

from . import config as cfg
from .factors import (
    compute_all_factors,
    get_factor_names,
    mad_zscore,
    cross_section_rank_target,
)
from .model import (
    train_lgbm,
    predict,
    save_model,
    load_model,
    model_path,
    static_model_path,
    prepare_train_matrix,
    HAS_LGBM,
)
class _MeanProxyModel:
    def predict(self, X):
        import numpy as np
        arr = np.asarray(X, dtype=float)
        if arr.ndim != 2 or arr.shape[1] == 0:
            return np.zeros(len(X))
        valid = np.isfinite(arr)
        sums = np.where(valid, arr, 0.0).sum(axis=1)
        counts = valid.sum(axis=1)
        return np.divide(sums, counts, out=np.zeros(arr.shape[0]), where=counts > 0)

from .filters import (
    filter_universe,
    apply_limit_rules,
    is_st_stock,
    is_limit_up,
    is_limit_down,
)


def _gm():
    from gm.api import (
        get_history_instruments,
        get_instruments,
        get_trading_dates,
        history,
        stk_get_index_constituents,
        get_symbol_infos,
    )
    return (
        get_history_instruments,
        get_instruments,
        get_trading_dates,
        history,
        stk_get_index_constituents,
        get_symbol_infos,
    )


def _get(o, k, default=None):
    return o.get(k, default) if isinstance(o, dict) else getattr(o, k, default)


def _project_root() -> str:
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


def _parse_date(value: str) -> datetime.date:
    return datetime.datetime.strptime(str(value)[:10], "%Y-%m-%d").date()


def _parse_date_range(value: str) -> Tuple[datetime.date, datetime.date]:
    if not value or ":" not in str(value):
        raise ValueError("oos_data must be yyyy-mm-dd:yyyy-mm-dd when walk-forward=false")
    start_text, end_text = str(value).split(":", 1)
    start = _parse_date(start_text.strip())
    end = _parse_date(end_text.strip())
    if start >= end:
        raise ValueError("oos_data start must be earlier than end: %s" % value)
    return start, end


def _walk_forward_train_range(year: int) -> Tuple[datetime.date, datetime.date]:
    return datetime.date(year - 3, 1, 1), datetime.date(year - 1, 12, 31)


class MultiFactorLightGBMStrategy:
    NAME = "multi_factor_lgbm"

    def __init__(self, demo: bool = False):
        self.demo = bool(demo) or cfg.DEMO_MODE
        self.factor_names = get_factor_names()
        self.models: Dict[int, Any] = {}          # year -> model
        self.static_model: Optional[Any] = None
        self.static_model_meta: Dict[str, Any] = {}
        self.pending_orders: Dict[str, dict] = {} # T+2 待执行
        self.last_rebalance_date: Optional[datetime.date] = None
        self.holdings: Set[str] = set()
        self.signal_cache: Dict[str, List[str]] = {}  # date_str -> top50
        self._trained_years: Set[int] = set()
        self._failed_training_years: Set[int] = set()
        self._data_cache: Dict[str, pd.DataFrame] = {}
        self._stats = defaultdict(int)

    # ------------------------------------------------------------------
    # 生命周期
    # ------------------------------------------------------------------
    def on_init(self, context):
        context.mfl_stats = dict(self._stats)
        context.mfl_holdings = set()
        context.mfl_pending = {}
        root = _project_root()
        os.makedirs(os.path.join(root, cfg.MODEL_DIR), exist_ok=True)
        static_range = _parse_date_range(cfg.OOS_DATA) if not cfg.WALK_FORWARD else None

        if self.demo:
            print("MULTI_FACTOR_LGBM INIT | DEMO_MODE | factors=%d | hold=%d | rebalance=%dd | T+%d | walk_forward=%s | oos_data=%s"
                  % (len(self.factor_names), cfg.HOLD_COUNT, cfg.REBALANCE_DAYS, cfg.TRADE_SHIFT,
                     cfg.WALK_FORWARD, cfg.OOS_DATA))
            self._init_demo(context)
            return

        # Universe 由 main.py / Select 层负责。策略层禁止擅自扩大 Universe，
        # 这样才能保证 HS300 默认约定、研究账户 Universe Switch 与执行层解耦。
        try:
            from gm.api import subscribe
            pool = list(getattr(context, "stock_pool", []) or [])
            if not pool:
                raise RuntimeError("stock_pool is empty; Universe must be initialized before strategy")
            subscribe(
                symbols=pool,
                frequency="1d",
                count=max(200, cfg.TRAIN_WINDOW // 3),
                fields="symbol,open,close,high,low,volume,amount",
                unsubscribe_previous=True,
            )
            print("MULTI_FACTOR_LGBM | universe=%d (managed by main/select)" % len(pool))
        except Exception as e:
            print("WARN multi_factor subscribe | %s" % e)

        print(
            "MULTI_FACTOR_LGBM INIT | factors=%d | hold=%d | rebalance=%dd | T+%d | train_window=%d | oos=%s | walk_forward=%s | static_train=%s"
            % (len(self.factor_names), cfg.HOLD_COUNT, cfg.REBALANCE_DAYS, cfg.TRADE_SHIFT,
               cfg.TRAIN_WINDOW, cfg.OOS_START, cfg.WALK_FORWARD, static_range)
        )

    def _init_demo(self, context):
        """本地 demo：生成合成行情，跑通训练→预测→选股全流程。"""
        rng = np.random.RandomState(42)
        n_stocks = cfg.DEMO_N_STOCKS
        n_days = cfg.DEMO_N_DAYS
        dates = pd.bdate_range("2010-01-04", periods=n_days)
        symbols = ["DEMO.%06d" % i for i in range(n_stocks)]
        context.stock_pool = symbols
        context.demo_dates = [d.date() for d in dates]
        context.demo_bars = {}
        context.demo_idx = 0

        for sym in symbols:
            ret = rng.normal(0.0003, 0.02, n_days)
            close = 10 * np.exp(np.cumsum(ret))
            high = close * (1 + rng.uniform(0, 0.02, n_days))
            low = close * (1 - rng.uniform(0, 0.02, n_days))
            open_ = close * (1 + rng.normal(0, 0.005, n_days))
            volume = rng.randint(1e5, 5e6, n_days).astype(float)
            amount = volume * close
            df = pd.DataFrame({
                "open": open_, "high": high, "low": low, "close": close,
                "volume": volume, "amount": amount,
            }, index=dates)
            context.demo_bars[sym] = df

        # 预计算全量因子面板（demo 用）
        print("DEMO | computing factors for %d stocks x %d days ..." % (n_stocks, n_days))
        panels = []
        for sym in symbols:
            fac = compute_all_factors(context.demo_bars[sym])
            if fac.empty:
                continue
            fac = fac.copy()
            fac["symbol"] = sym
            fac["date"] = fac.index.date
            # 未来 5 日收益
            c = context.demo_bars[sym]["close"].values
            fut = np.full(len(c), np.nan)
            fut[:-cfg.TARGET_HORIZON] = c[cfg.TARGET_HORIZON:] / c[:-cfg.TARGET_HORIZON] - 1
            fac["fwd_ret"] = fut
            panels.append(fac.reset_index(drop=True))
        context.demo_panel = pd.concat(panels, ignore_index=True) if panels else pd.DataFrame()
        print("DEMO | panel rows=%d | factors=%d" % (len(context.demo_panel), len(self.factor_names)))

        # 预先训练若干年模型
        self._demo_train_all(context)

    def _demo_train_all(self, context):
        panel = getattr(context, "demo_panel", None)
        if panel is None or panel.empty:
            return
        root = _project_root()
        if not cfg.WALK_FORWARD:
            start, end = _parse_date_range(cfg.OOS_DATA)
            path = static_model_path(root)
            cached = self._try_load_static_model(path)
            if cached is not None:
                self.static_model, self.static_model_meta = cached
                print("DEMO | loaded model_static.pkl | meta=%s" % self.static_model_meta)
                return
            fitted = self._fit_model_from_panel(
                panel, start, end, path,
                {"walk_forward": False, "oos_data": cfg.OOS_DATA},
                "static",
            )
            if fitted is not None:
                self.static_model, self.static_model_meta = fitted
                self._trained_years.add(0)
            return

        for year in range(2013, 2016):
            start, end = _walk_forward_train_range(year)
            path = model_path(root, year)
            cached = self._try_load_walk_model(path, year, start, end)
            if cached is not None:
                self.models[year] = cached[0]
                self._trained_years.add(year)
                print("DEMO | loaded model_%d.pkl | meta=%s" % (year, cached[1]))
                continue
            fitted = self._fit_model_from_panel(
                panel, start, end, path,
                {"walk_forward": True, "year": year},
                "model_%d" % year,
            )
            if fitted is not None:
                self.models[year] = fitted[0]
                self._trained_years.add(year)

    def _try_load_walk_model(
        self,
        path: str,
        year: int,
        train_start: datetime.date,
        train_end: datetime.date,
    ) -> Optional[Tuple[Any, Dict]]:
        if not os.path.exists(path):
            return None
        try:
            model, meta = load_model(path)
        except Exception as e:
            print("WARN load model_%d | %s" % (year, e))
            return None
        if (
            meta.get("walk_forward") is True
            and int(meta.get("year", -1)) == int(year)
            and meta.get("train_start") == str(train_start)
            and meta.get("train_end") == str(train_end)
        ):
            return model, meta
        print("MFL | stale model_%d.pkl ignored | meta=%s" % (year, meta))
        return None

    def _try_load_static_model(self, path: str) -> Optional[Tuple[Any, Dict]]:
        if not os.path.exists(path):
            return None
        try:
            model, meta = load_model(path)
        except Exception as e:
            print("WARN load model_static | %s" % e)
            return None
        if meta.get("walk_forward") is False and meta.get("oos_data") == cfg.OOS_DATA:
            return model, meta
        print("MFL | stale model_static.pkl ignored | meta=%s" % meta)
        return None

    def _drop_target_lookahead(self, panel: pd.DataFrame) -> pd.DataFrame:
        if panel is None or panel.empty:
            return pd.DataFrame()
        dates = sorted(panel["date"].dropna().unique())
        if len(dates) <= cfg.TARGET_HORIZON:
            return pd.DataFrame()
        cutoff = dates[-cfg.TARGET_HORIZON - 1]
        return panel[panel["date"] <= cutoff].copy()

    def _scale_train_frame(self, train_df: pd.DataFrame, feature_cols: List[str]) -> pd.DataFrame:
        parts = []
        for _, part in train_df.groupby("date", sort=False):
            part = part.copy()
            part[feature_cols] = mad_zscore(part[feature_cols], cfg.MAD_N)
            parts.append(part)
        return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()

    def _fit_model_from_panel(
        self,
        panel: pd.DataFrame,
        train_start: datetime.date,
        train_end: datetime.date,
        path: str,
        meta: Dict,
        label: str,
    ) -> Optional[Tuple[Any, Dict]]:
        sub = panel[(panel["date"] >= train_start) & (panel["date"] <= train_end)].copy()
        sub = self._drop_target_lookahead(sub)
        if len(sub) < cfg.MIN_TRAIN_ROWS:
            print("MFL | skip training %s | rows=%d < %d" % (label, len(sub), cfg.MIN_TRAIN_ROWS))
            return None
        n_dates = int(pd.Series(sub["date"]).nunique())
        if n_dates < cfg.MIN_TRAIN_DATES:
            print("MFL | skip training %s | dates=%d < %d" % (label, n_dates, cfg.MIN_TRAIN_DATES))
            return None
        sub["target"] = sub.groupby("date")["fwd_ret"].transform(
            lambda x: cross_section_rank_target(x)
        )
        feat = [c for c in self.factor_names if c in sub.columns]
        if not feat:
            print("MFL | skip training %s | no features" % label)
            return None
        train_df = sub[["date", "symbol", "target"] + feat].copy()
        train_df = self._scale_train_frame(train_df, feat)
        X, y, groups = prepare_train_matrix(train_df, feat, "target", "date")
        if len(X) < cfg.MIN_TRAIN_ROWS:
            print("MFL | skip training %s | samples=%d < %d" % (label, len(X), cfg.MIN_TRAIN_ROWS))
            return None
        if not HAS_LGBM:
            print("WARN | lightgbm not installed, using mean proxy model for %s" % label)
            model = _MeanProxyModel()
        else:
            model = train_lgbm(X, y, groups)
        saved_meta = dict(meta)
        saved_meta.update({
            "train_start": str(train_start),
            "train_end": str(train_end),
            "label_end": str(max(train_df["date"])),
            "target_horizon": cfg.TARGET_HORIZON,
            "n_samples": len(X),
            "n_features": len(feat),
            "early_stopping": False,
        })
        save_model(model, path, saved_meta)
        print("MFL | trained %s | train=%s:%s | label_end=%s | samples=%d | features=%d"
              % (label, train_start, train_end, saved_meta["label_end"], len(X), len(feat)))
        return model, saved_meta

    # ------------------------------------------------------------------
    # 主循环
    # ------------------------------------------------------------------
    def on_bar(self, context):
        if self.demo:
            self._on_bar_demo(context)
            return

        import backtest_config as bt
        today = context.now.date() if hasattr(context.now, "date") else context.now
        start = datetime.datetime.strptime(bt.START, "%Y-%m-%d").date()
        end = datetime.datetime.strptime(bt.END, "%Y-%m-%d").date()
        if today < start or today > end:
            return
        if cfg.WALK_FORWARD:
            if today < _parse_date(cfg.OOS_START):
                return
        elif not cfg.ALLOW_STATIC_TRAIN_OVERLAP:
            _, static_train_end = _parse_date_range(cfg.OOS_DATA)
            if today <= static_train_end:
                return

        if context.today != today:
            context.today = today
            context.turnover_value = 0.0

        # 交易日历
        try:
            _, _, get_trading_dates, *_ = _gm()
            if not getattr(context, "trading_dates_sorted", None):
                context.trading_dates_sorted = sorted(
                    pd.Timestamp(x).date()
                    for x in get_trading_dates(exchange="SHSE", start_date=bt.START, end_date=bt.END)
                )
        except Exception:
            pass

        # 1. 执行 T+2 待执行订单
        self._execute_pending(context, today)

        # 2. 判断是否调仓日
        if not self._is_rebalance_day(context, today):
            return

        # 3. 确保当年模型已训练/加载
        year = today.year
        if not self._ensure_model(context, year):
            print("MFL | %s | no valid model, skip signal" % today)
            return

        # 4. 计算当日因子横截面，预测，选 Top50
        top50 = self._select_top50(context, today)
        if not top50:
            print("MFL | %s | no candidates after filter" % today)
            return

        self.signal_cache[str(today)] = top50
        print("MFL SIGNAL | %s | Top50[:5]=%s ..." % (today, top50[:5]))

        # 5. T+2 挂单：信号日 t，执行日 t+2
        exec_date = self._shift_trading_day(context, today, cfg.TRADE_SHIFT)
        context.mfl_pending = getattr(context, "mfl_pending", {})
        context.mfl_pending[str(exec_date)] = {
            "signal_date": str(today),
            "target": top50,
            "weight": cfg.WEIGHT_PER_STOCK,
        }
        self.last_rebalance_date = today

    def _on_bar_demo(self, context):
        """Demo 模式：推进合成日期，输出最近调仓日 Top50。"""
        dates = getattr(context, "demo_dates", [])
        idx = getattr(context, "demo_idx", 0)
        if idx >= len(dates):
            return
        today = dates[idx]
        context.demo_idx = idx + 1
        context.now = datetime.datetime.combine(today, datetime.time(14, 50))

        # 每 5 个交易日调仓
        if idx % cfg.REBALANCE_DAYS != 0:
            return
        year = today.year
        if cfg.WALK_FORWARD:
            if today < _parse_date(cfg.OOS_START):
                return
            model = self.models.get(year)
        else:
            if not cfg.ALLOW_STATIC_TRAIN_OVERLAP:
                _, static_train_end = _parse_date_range(cfg.OOS_DATA)
                if today <= static_train_end:
                    return
            model = self.static_model
        if model is None:
            print("DEMO | no model for %s" % today)
            return

        panel = context.demo_panel
        day_df = panel[panel["date"] == today].copy()
        if day_df.empty:
            return
        feat = [c for c in self.factor_names if c in day_df.columns]
        X = mad_zscore(day_df[feat], cfg.MAD_N)
        scores = predict(model, X)
        day_df = day_df.copy()
        day_df["score"] = scores
        day_df = day_df.sort_values("score", ascending=False)
        top50 = day_df["symbol"].head(cfg.HOLD_COUNT).tolist()
        self.signal_cache[str(today)] = top50
        print("DEMO SIGNAL | %s | year=%d | Top50[:8]=%s" % (today, year, top50[:8]))
        # 模拟 T+2
        if idx + cfg.TRADE_SHIFT < len(dates):
            exec_d = dates[idx + cfg.TRADE_SHIFT]
            print("DEMO T+2 EXEC | signal=%s -> exec=%s | hold=%d @ %.1f%% each"
                  % (today, exec_d, len(top50), cfg.WEIGHT_PER_STOCK * 100))

    # ------------------------------------------------------------------
    # 模型
    # ------------------------------------------------------------------
    def _ensure_model(self, context, year: int) -> bool:
        if cfg.WALK_FORWARD:
            now = getattr(context, "now", None)
            today = now.date() if hasattr(now, "date") else now
            if today is not None and today < _parse_date(cfg.OOS_START):
                return False
        root = _project_root()
        if not cfg.WALK_FORWARD:
            if self.static_model is not None:
                return True
            path = static_model_path(root)
            cached = self._try_load_static_model(path)
            if cached is not None:
                self.static_model, self.static_model_meta = cached
                print("MFL | loaded model_static.pkl | meta=%s" % self.static_model_meta)
                return True
            train_start, train_end = _parse_date_range(cfg.OOS_DATA)
            print("MFL | training static model | train=%s:%s ..." % (train_start, train_end))
            panel = self._build_training_panel(context, train_start, train_end)
            fitted = self._fit_model_from_panel(
                panel, train_start, train_end, path,
                {"walk_forward": False, "oos_data": cfg.OOS_DATA},
                "static",
            )
            if fitted is None:
                return False
            self.static_model, self.static_model_meta = fitted
            self._trained_years.add(0)
            return True

        if year in self.models:
            return True
        if year in self._failed_training_years:
            return False
        train_start, train_end = _walk_forward_train_range(year)
        path = model_path(root, year)
        cached = self._try_load_walk_model(path, year, train_start, train_end)
        if cached is not None:
            self.models[year] = cached[0]
            self._trained_years.add(year)
            print("MFL | loaded model_%d.pkl | meta=%s" % (year, cached[1]))
            return True

        print("MFL | training model_%d | train=%s:%s ..." % (year, train_start, train_end))
        panel = self._build_training_panel(context, train_start, train_end)
        fitted = self._fit_model_from_panel(
            panel, train_start, train_end, path,
            {"walk_forward": True, "year": year},
            "model_%d" % year,
        )
        if fitted is None:
            self._failed_training_years.add(year)
            return False
        self.models[year] = fitted[0]
        self._trained_years.add(year)
        return True

    # ------------------------------------------------------------------
    # 选股
    # ------------------------------------------------------------------
    def _rank_candidates(self, context, today: datetime.date, limit: Optional[int] = None) -> List[Tuple[str, float, str]]:
        year = today.year
        model = self.models.get(year) if cfg.WALK_FORWARD else self.static_model
        if model is None:
            return []
        pool = list(getattr(context, "stock_pool", []) or [])
        if not pool:
            return []

        # 批量取最近行情并算因子（控制数量）
        scores = []
        bar_map = {}
        need_bars = 130
        for i, sym in enumerate(pool):
            if i > 0 and i % 500 == 0:
                print("MFL | scoring progress %d/%d" % (i, len(pool)))
            try:
                df = self._get_bars(context, sym, need_bars)
                if df is None or len(df) < 60:
                    continue
                fac = compute_all_factors(df)
                if fac.empty or fac.iloc[-1].isna().mean() > 0.5:
                    continue
                row = fac.iloc[-1][self.factor_names]
                # 简单流动性
                vol = float(df["volume"].iloc[-1]) if "volume" in df.columns else 0
                amt = float(df["amount"].iloc[-1]) if "amount" in df.columns else float(df["close"].iloc[-1]) * vol
                amt20 = float(df["amount"].tail(20).mean()) if "amount" in df.columns else amt
                bar_map[sym] = {
                    "volume": vol,
                    "amount": amt,
                    "amount_20d_avg": amt20,
                    "open": float(df["open"].iloc[-1]),
                    "close": float(df["close"].iloc[-1]),
                    "pre_close": float(df["close"].iloc[-2]) if len(df) > 1 else float(df["close"].iloc[-1]),
                }
                scores.append((sym, row))
            except Exception:
                continue

        if not scores:
            return []

        # 横截面矩阵
        syms = [s for s, _ in scores]
        mat = pd.DataFrame([r.values for _, r in scores], columns=self.factor_names, index=syms)
        mat = mad_zscore(mat, cfg.MAD_N)

        if model is not None:
            pred = predict(model, mat)
        else:
            pred = mat.mean(axis=1).values

        rank_df = pd.DataFrame({"symbol": syms, "score": pred})
        rank_df = rank_df.sort_values("score", ascending=False)

        # 可交易过滤
        candidates = rank_df["symbol"].tolist()
        try:
            gm_funcs = _gm()[:2]
        except Exception:
            gm_funcs = None
        passed = filter_universe(candidates, str(today), bar_map, gm_funcs)
        ranked = []
        for sym in passed:
            if sym not in set(candidates):
                continue
            idx = candidates.index(sym)
            score = float(rank_df.loc[rank_df["symbol"] == sym, "score"].iloc[0])
            ranked.append((sym, score, "mfl_rank=%d" % (idx + 1)))
            if limit is not None and len(ranked) >= limit:
                break
        return ranked

    def _select_top50(self, context, today: datetime.date) -> List[str]:
        ranked = self._rank_candidates(context, today, limit=cfg.HOLD_COUNT)
        return [s for s, _, _ in ranked]

    def _build_training_panel(
        self,
        context,
        train_start: datetime.date,
        train_end: datetime.date,
    ) -> pd.DataFrame:
        pool = list(getattr(context, "stock_pool", []) or [])
        if not pool:
            print("MFL | training skipped: empty stock_pool")
            return pd.DataFrame()
        panels = []
        for i, sym in enumerate(pool):
            if i > 0 and i % 200 == 0:
                print("MFL | training data progress %d/%d | rows=%d" % (i, len(pool), sum(len(x) for x in panels)))
            df = self._get_bars_by_date(context, sym, train_start, train_end)
            if df is None or len(df) < max(60, cfg.TARGET_HORIZON + 30):
                continue
            try:
                df = self._normalize_bars(df)
                fac = compute_all_factors(df)
                if fac.empty:
                    continue
                close = df["close"].astype(float).values
                fwd_ret = np.full(len(close), np.nan)
                fwd_ret[:-cfg.TARGET_HORIZON] = (
                    close[cfg.TARGET_HORIZON:] / close[:-cfg.TARGET_HORIZON] - 1
                )
                fac = fac.copy()
                fac["symbol"] = sym
                fac["date"] = fac.index.date
                fac["fwd_ret"] = fwd_ret
                panels.append(fac.reset_index(drop=True))
            except Exception as e:
                self._stats["train_symbol_errors"] += 1
                if self._stats["train_symbol_errors"] <= 5:
                    print("WARN train data %s | %s" % (sym, e))
                continue
        if not panels:
            return pd.DataFrame()
        return pd.concat(panels, ignore_index=True)

    def _normalize_bars(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        if not isinstance(out.index, pd.DatetimeIndex):
            for col in ("eob", "bob", "time", "date", "trade_date"):
                if col in out.columns:
                    out.index = pd.to_datetime(out[col])
                    break
        out = out.sort_index()
        for col in ("open", "high", "low", "close", "volume"):
            if col not in out.columns:
                raise ValueError("missing bar column: %s" % col)
        if "amount" not in out.columns:
            out["amount"] = out["close"].astype(float) * out["volume"].astype(float)
        return out[["open", "high", "low", "close", "volume", "amount"]].astype(float)

    def _get_bars_by_date(
        self,
        context,
        symbol: str,
        start: datetime.date,
        end: datetime.date,
    ) -> Optional[pd.DataFrame]:
        key = "train:%s:%s:%s" % (symbol, start, end)
        if key in self._data_cache:
            return self._data_cache[key]
        try:
            from gm.api import history as gm_history
            df = gm_history(
                symbol=symbol,
                frequency="1d",
                start_time=str(start) + " 09:00:00",
                end_time=str(end) + " 15:00:00",
                fields="open,high,low,close,volume,amount,eob",
                adjust=1,
                df=True,
            )
        except TypeError:
            try:
                from gm.api import history as gm_history
                df = gm_history(
                    symbol=symbol,
                    frequency="1d",
                    start_date=str(start),
                    end_date=str(end),
                    fields="open,high,low,close,volume,amount,eob",
                    adjust=1,
                    df=True,
                )
            except Exception:
                return None
        except Exception:
            return None
        if df is not None and len(df) > 0:
            self._data_cache[key] = df
        return df

    def _get_bars(self, context, symbol: str, count: int) -> Optional[pd.DataFrame]:
        """优先 context.data / broker.history，回退 gm.history。"""
        try:
            if hasattr(context, "data"):
                df = context.data(symbol=symbol, frequency="1d", count=count,
                                  fields="open,high,low,close,volume,amount")
                if df is not None and len(df) > 0:
                    return df
        except Exception:
            pass
        try:
            if hasattr(context, "broker") and hasattr(context.broker, "history"):
                df = context.broker.history(symbol, count, "open,high,low,close,volume,amount")
                if df is not None and len(df) > 0:
                    return df
        except Exception:
            pass
        try:
            from gm.api import history as gm_history
            df = gm_history(
                symbol=symbol, frequency="1d", count=count,
                fields="open,high,low,close,volume,amount",
                adjust=1, df=True,
            )
            return df
        except Exception:
            return None

    # ------------------------------------------------------------------
    # 调仓与 T+2
    # ------------------------------------------------------------------
    def _is_rebalance_day(self, context, today: datetime.date) -> bool:
        dates = getattr(context, "trading_dates_sorted", None) or []
        if not dates:
            # 无日历时，每 5 自然日近似
            if self.last_rebalance_date is None:
                return True
            return (today - self.last_rebalance_date).days >= cfg.REBALANCE_DAYS
        try:
            idx = dates.index(today)
        except ValueError:
            return False
        if self.last_rebalance_date is None:
            return True
        try:
            last_idx = dates.index(self.last_rebalance_date)
            return (idx - last_idx) >= cfg.REBALANCE_DAYS
        except ValueError:
            return (today - self.last_rebalance_date).days >= cfg.REBALANCE_DAYS

    def _shift_trading_day(self, context, today: datetime.date, n: int) -> datetime.date:
        dates = getattr(context, "trading_dates_sorted", None) or []
        if not dates:
            return today + datetime.timedelta(days=n)
        try:
            idx = dates.index(today)
            target = idx + n
            if target < len(dates):
                return dates[target]
            return dates[-1]
        except ValueError:
            return today + datetime.timedelta(days=n)

    def _execute_pending(self, context, today: datetime.date):
        pending = getattr(context, "mfl_pending", {}) or {}
        key = str(today)
        if key not in pending:
            return
        order = pending.pop(key)
        target = order.get("target") or []
        weight = float(order.get("weight", cfg.WEIGHT_PER_STOCK))
        print("MFL EXEC T+2 | %s | signal=%s | n=%d" % (today, order.get("signal_date"), len(target)))

        # 当前持仓：正式环境以账户真实持仓为准；逻辑 holdings 仅作为无 Broker 场景回退。
        try:
            live_positions = broker.positions() if broker is not None else []
        except Exception:
            live_positions = []
        if live_positions:
            current = {
                str(p.get("symbol"))
                for p in live_positions
                if str(p.get("symbol", "")) and int(p.get("volume", 0) or 0) > 0
            }
        else:
            current = set(getattr(context, "mfl_holdings", set()) or self.holdings)
        to_sell = list(current - set(target))
        to_buy = list(set(target) - current)

        # 涨跌停过滤
        bar_map = {}
        for sym in set(to_buy + to_sell):
            df = self._get_bars(context, sym, 5)
            if df is not None and len(df) >= 2:
                bar_map[sym] = {
                    "open": float(df["open"].iloc[-1]),
                    "pre_close": float(df["close"].iloc[-2]),
                    "close": float(df["close"].iloc[-1]),
                }
        to_buy, to_sell = apply_limit_rules(to_buy, to_sell, current, bar_map)

        # 下单（通过 broker）
        broker = getattr(context, "broker", None)
        if broker is None:
            # 仅更新逻辑持仓
            self.holdings = (current - set(to_sell)) | set(to_buy)
            context.mfl_holdings = self.holdings
            print("MFL | logical holdings=%d (no broker)" % len(self.holdings))
            return

        # 卖出：统一走 Broker Adapter，禁止策略层直接调用 gm.api.order_volume。
        # Broker 会从账户真实持仓获取 available volume，并处理 T+1 可卖数量。
        for sym in to_sell:
            try:
                broker.sell_all(sym)
            except Exception as e:
                print("WARN sell %s | %s" % (sym, e))

        # 买入等权
        try:
            nav = float(getattr(context, "account", None) and context.account().cash.nav or root_config.INIT_CAPITAL)
        except Exception:
            nav = float(root_config.INIT_CAPITAL)
        target_val = nav * weight
        for sym in to_buy:
            try:
                price = bar_map.get(sym, {}).get("open") or bar_map.get(sym, {}).get("close")
                if not price or price <= 0:
                    continue
                lots = min_lot_size(sym) if callable(min_lot_size) else 100
                vol = int(target_val / price / lots) * lots
                if vol >= lots:
                    # Broker.buy 统一负责交易单位、开仓方向与 gm.api 订单参数。
                    broker.buy(sym, vol)
            except Exception as e:
                print("WARN buy %s | %s" % (sym, e))

        self.holdings = (current - set(to_sell)) | set(to_buy)
        context.mfl_holdings = self.holdings

    def on_backtest_finished(self, context, indicator):
        print("MFL BACKTEST FINISHED | %s" % indicator)
        print("MFL | last signals: %s" % list(self.signal_cache.items())[-3:])
        print("MFL | trained years: %s" % sorted(self._trained_years))
        print("MFL | final holdings: %d" % len(getattr(context, "mfl_holdings", self.holdings)))
