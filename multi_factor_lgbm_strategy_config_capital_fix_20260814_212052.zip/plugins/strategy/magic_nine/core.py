# -*- coding: utf-8 -*-
"""Magic Nine helpers — trend, TD9, volume score, risk filters (V6.3).

Imported by plugins.strategy.magic_nine.
"""
from __future__ import annotations

import datetime
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import config
from strategy.data_guard import closed_daily_data
from strategy.volume_confirm import evaluate as volume_evaluate
from strategy.lot_rules import min_lot_size

NEED_BARS = 130
TD_LOOKBACK = 4
SETUP_LEN = 9
SIGNAL_MAX_AGE = 2
MIN_PRICE = 3.0
MIN_AVG_AMOUNT = 2.0e6
MAX_ATR_PCT = 0.10
MIN_VOLUME_RATIO = 0.70
INDEX_BEAR_BLOCK = True
REQUIRE_UPTREND_STRUCTURE = True
ALLOW_RANGE_ENTRY = True
ALLOW_WEAK_ENTRY = False
REQUIRE_PERFECTED = False
FREEFALL_RET5 = -0.10
FREEFALL_ATR_EXPAND = 1.35
TREND_SCORE_MIN = 0.50
ENTRY_SCORE_MIN = 0.65
COOLDOWN_DAYS = 3
REQUIRE_BOUNCE_CONFIRM = True
REQUIRE_ABOVE_MA60 = True
REQUIRE_VOLUME_CONFIRM = True
VOLUME_CONFIRM_MIN = 0.30
VOLUME_SCORE_WEIGHT = 0.20
MAX_DAILY_SIGNALS = 5
SHORT_ENTRY_SCORE_MIN = 0.70
SHORT_TREND_FLOOR = 0.35
SHORT_REQUIRE_AGE0 = False  # age 0 or 1
SHORT_VOL_MIN = 0.48


def _gm():
    from gm.api import get_history_instruments, get_instruments, get_trading_dates
    return get_history_instruments, get_instruments, get_trading_dates


def _get(o, k, default=None):
    return o.get(k, default) if isinstance(o, dict) else getattr(o, k, default)


def _sec_level(row):
    value = _get(row, "sec_level", 1)
    try:
        return int(value)
    except (TypeError, ValueError):
        return 99


def is_st_stock(symbol, trade_date=None):
    if trade_date is None:
        trade_date = datetime.date.today().strftime("%Y-%m-%d")
    try:
        get_history_instruments, _, _ = _gm()
        rows = get_history_instruments(
            symbols=[symbol],
            start_date=trade_date,
            end_date=trade_date,
            fields="symbol,sec_level,is_suspended,created_at",
            df=True,
        )
        if rows is None or len(rows) == 0:
            return True
        return _sec_level(rows.iloc[-1]) in (2, 3, 12, 13)
    except Exception as e:
        print("WARN ST CHECK | %s | date=%s | %s" % (symbol, trade_date, e))
        return True


def _finite_arr(*arrays):
    for a in arrays:
        if a is None or len(a) == 0 or not np.all(np.isfinite(a)):
            return False
    return True


def _atr_series(high, low, close, period=14):
    if len(close) < period + 1:
        return None
    tr = np.maximum(
        high[1:] - low[1:],
        np.maximum(np.abs(high[1:] - close[:-1]), np.abs(low[1:] - close[:-1])),
    )
    if len(tr) < period:
        return None
    out = np.full(len(close), np.nan)
    for i in range(period, len(tr) + 1):
        out[i] = float(np.mean(tr[i - period:i]))
    return out


def compute_td_setup(close, high, low, signal_max_age=SIGNAL_MAX_AGE):
    n = len(close)
    buy_count = np.zeros(n, dtype=int)
    sell_count = np.zeros(n, dtype=int)
    for i in range(TD_LOOKBACK, n):
        if close[i] < close[i - TD_LOOKBACK]:
            prev = int(buy_count[i - 1])
            buy_count[i] = prev + 1 if prev < SETUP_LEN else SETUP_LEN
        else:
            buy_count[i] = 0
        if close[i] > close[i - TD_LOOKBACK]:
            prev = int(sell_count[i - 1])
            sell_count[i] = prev + 1 if prev < SETUP_LEN else SETUP_LEN
        else:
            sell_count[i] = 0

    def _completion_age(counts):
        last = -1
        for j in range(n - 1, TD_LOOKBACK - 1, -1):
            if counts[j] == SETUP_LEN and (
                    j == TD_LOOKBACK or counts[j - 1] == SETUP_LEN - 1):
                last = j
                break
        if last < 0:
            return 999, False, -1
        age = n - 1 - last
        return age, age <= signal_max_age, last

    age_buy, active_buy, last_buy9 = _completion_age(buy_count)
    age_sell, active_sell, last_sell9 = _completion_age(sell_count)
    return {
        "buy_count": int(buy_count[-1]),
        "sell_count": int(sell_count[-1]),
        "buy9_age": int(age_buy),
        "sell9_age": int(age_sell),
        "last_buy9": int(last_buy9),
        "active_buy9": bool(active_buy),
        "active_sell9": bool(active_sell),
    }


def bounce_confirm(close, ma20, td, soft=False):
    """Return True if price shows bounce / stabilization after TD9.

    soft=True: used by short_strong path — allows flat days near MA20.
    """
    if len(close) < 3:
        return False
    last = float(close[-1])
    prev = float(close[-2])
    if soft:
        bounce = last >= prev * 0.997 or (ma20 > 0 and last >= ma20 * 0.992)
    else:
        bounce = last > prev or (ma20 > 0 and last >= ma20 * 0.995)
    if not bounce:
        return False
    i9 = int(td.get("last_buy9", -1))
    floor = 0.98 if soft else 0.985
    if i9 >= 0 and i9 < len(close):
        if last < float(close[i9]) * floor:
            return False
        if last < float(np.min(close[max(0, i9 - 2):i9 + 1])) * (0.985 if soft else 0.99):
            return False
    return True


def multi_period_trend(close, index_close):
    if len(close) < 120:
        ma20 = float(np.mean(close[-min(20, len(close)):])) if len(close) else 0.0
        return {
            "ok": False, "score": 0.0, "regime": "unknown", "detail": "short_hist",
            "ma20": ma20, "ma60": ma20, "ma120": ma20,
            "slope20": 0.0, "slope60": 0.0, "excess20": 0.0, "excess60": 0.0,
        }

    c = close
    price = float(c[-1])
    ma20 = float(np.mean(c[-20:]))
    ma60 = float(np.mean(c[-60:]))
    ma120 = float(np.mean(c[-120:]))
    ma20_prev = float(np.mean(c[-25:-5]))
    ma60_prev = float(np.mean(c[-70:-10]))
    slope20 = ma20 / ma20_prev - 1.0 if ma20_prev > 0 else 0.0
    slope60 = ma60 / ma60_prev - 1.0 if ma60_prev > 0 else 0.0

    score = 0.0
    if price > ma120:
        score += 0.18
    if ma60 > ma120:
        score += 0.14
    if slope60 >= 0:
        score += 0.12
    elif slope60 > -0.01:
        score += 0.04
    if price >= ma60 * 0.985:
        score += 0.16
    elif price >= ma60 * 0.97:
        score += 0.06
    if ma20 >= ma60 * 0.99:
        score += 0.10
    if slope20 > -0.02:
        score += 0.08
    if price <= ma20 * 1.03:
        score += 0.06
    if price <= ma20 * 1.00:
        score += 0.04

    excess20 = 0.0
    excess60 = 0.0
    if index_close is not None and len(index_close) >= 60:
        ret20 = price / float(c[-20]) - 1.0
        ret60 = price / float(c[-60]) - 1.0
        iret20 = float(index_close[-1]) / float(index_close[-20]) - 1.0
        iret60 = float(index_close[-1]) / float(index_close[-60]) - 1.0
        excess20 = ret20 - iret20
        excess60 = ret60 - iret60
        if excess60 > 0:
            score += 0.08
        elif excess60 > -0.03:
            score += 0.04
        if excess20 > -0.05:
            score += 0.04

    regime = "range"
    if index_close is not None and len(index_close) >= 60:
        ip = float(index_close[-1])
        ima20 = float(np.mean(index_close[-20:]))
        ima60 = float(np.mean(index_close[-60:]))
        ibase = float(np.mean(index_close[-25:-5]))
        islope = ima20 / ibase - 1.0 if ibase > 0 else 0.0
        if ip > ima20 and ima20 > ima60 and islope > 0:
            regime = "strong"
        elif ip > ima60:
            regime = "range"
        elif ip > ima60 * 0.97:
            regime = "weak"
        else:
            regime = "bear"

    ok = score >= TREND_SCORE_MIN
    if REQUIRE_UPTREND_STRUCTURE:
        if REQUIRE_ABOVE_MA60 and price < ma60 * 0.97:
            ok = False
        if ma60 < ma120 * 0.96 and slope60 < -0.005:
            ok = False
        if price < ma120 * 0.92:
            ok = False
        if regime == "bear" and INDEX_BEAR_BLOCK:
            ok = False
        if regime == "weak" and not ALLOW_WEAK_ENTRY:
            ok = False

    return {
        "ok": bool(ok),
        "score": float(max(0.0, min(1.0, score))),
        "regime": regime,
        "ma20": ma20,
        "ma60": ma60,
        "ma120": ma120,
        "slope20": slope20,
        "slope60": slope60,
        "excess20": excess20,
        "excess60": excess60,
        "detail": "trend:%.2f regime:%s xs20:%+.1f%%" % (score, regime, excess20 * 100),
    }


def risk_filters(close, high, low, volume, price):
    if price < MIN_PRICE or price <= 0:
        return False, "price"
    if len(close) < 25 or len(volume) < 25:
        return False, "bars"
    avg_amt = float(np.mean(volume[-20:])) * price
    if avg_amt < MIN_AVG_AMOUNT:
        return False, "liquidity"
    vol5 = float(np.mean(volume[-5:]))
    vol20 = float(np.mean(volume[-20:]))
    if vol20 <= 0 or vol5 / vol20 < MIN_VOLUME_RATIO:
        return False, "volume_dry"
    atr = _atr_series(high, low, close, 14)
    if atr is None or not np.isfinite(atr[-1]):
        return False, "atr"
    atr_pct = float(atr[-1]) / price
    if atr_pct > MAX_ATR_PCT:
        return False, "atr_high"
    ret5 = price / float(close[-5]) - 1.0
    if ret5 <= FREEFALL_RET5:
        return False, "freefall_ret"
    if len(atr) >= 20 and np.isfinite(atr[-6]):
        recent = float(np.nanmean(atr[-5:]))
        prior = float(np.nanmean(atr[-15:-5]))
        if prior > 0 and recent / prior >= FREEFALL_ATR_EXPAND and ret5 < -0.04:
            return False, "freefall_atr"
    return True, "ok"


def score_signal(td, trend, vol_score=0.5):
    base = 0.55
    if td["buy9_age"] == 0:
        base += 0.14
    elif td["buy9_age"] == 1:
        base += 0.08
    elif td["buy9_age"] == 2:
        base += 0.03
    base += 0.26 * float(trend.get("score", 0.0))
    if trend.get("regime") == "strong":
        base += 0.07
    elif trend.get("regime") == "range":
        base += 0.03
    elif trend.get("regime") == "bear":
        base -= 0.12
    xs60 = float(trend.get("excess60", 0.0))
    if xs60 > 0:
        base += 0.04
    xs20 = float(trend.get("excess20", 0.0))
    if xs20 > 0.02:
        base += 0.04
    elif xs20 > 0:
        base += 0.02
    base += VOLUME_SCORE_WEIGHT * (float(vol_score) - 0.45)
    return float(max(0.0, min(1.0, base)))


def short_score_signal(td, trend, vol_score=0.5):
    """Score for high-conviction short-term path — volume + freshness heavy."""
    base = 0.48
    if td["buy9_age"] == 0:
        base += 0.18
    elif td["buy9_age"] == 1:
        base += 0.10
    base += 0.16 * float(trend.get("score", 0.0))
    base += 0.28 * (float(vol_score) - 0.30)
    xs20 = float(trend.get("excess20", 0.0))
    if xs20 > 0.01:
        base += 0.06
    elif xs20 > -0.02:
        base += 0.02
    if trend.get("regime") == "strong":
        base += 0.04
    elif trend.get("regime") == "bear":
        base -= 0.15
    return float(max(0.0, min(1.0, base)))
