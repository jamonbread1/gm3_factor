# -*- coding: utf-8 -*-
from .strategy import MagicNineStrategy

__all__ = ["MagicNineStrategy"]
