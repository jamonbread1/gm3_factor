# -*- coding: utf-8 -*-
"""Magic Nine strategy class (V6.3). Helpers live in magic_nine/core.py."""
from __future__ import annotations

import datetime
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import config
from plugins import registry
from strategy.data_guard import closed_daily_data
from strategy.portfolio import capital_profile, target_value
from strategy.volume_confirm import evaluate as volume_evaluate
from strategy.lot_rules import min_lot_size

from .core import (
    NEED_BARS, SIGNAL_MAX_AGE, INDEX_BEAR_BLOCK, REQUIRE_UPTREND_STRUCTURE,
    ENTRY_SCORE_MIN, COOLDOWN_DAYS, REQUIRE_BOUNCE_CONFIRM, REQUIRE_VOLUME_CONFIRM,
    VOLUME_CONFIRM_MIN, MAX_DAILY_SIGNALS, SHORT_ENTRY_SCORE_MIN, SHORT_TREND_FLOOR,
    SHORT_REQUIRE_AGE0, SHORT_VOL_MIN,
    _gm, is_st_stock, _finite_arr, _atr_series, compute_td_setup, bounce_confirm,
    multi_period_trend, risk_filters, score_signal, short_score_signal,
)


class MagicNineStrategy:
    NAME = "magic_nine"

    def __init__(self,
                 signal_max_age: int = SIGNAL_MAX_AGE,
                 require_perfected: bool = False,
                 require_uptrend: bool = REQUIRE_UPTREND_STRUCTURE,
                 index_bear_block: bool = INDEX_BEAR_BLOCK,
                 need_bars: int = NEED_BARS,
                 entry_score_min: float = ENTRY_SCORE_MIN,
                 cooldown_days: int = COOLDOWN_DAYS,
                 require_bounce: bool = REQUIRE_BOUNCE_CONFIRM,
                 require_volume: bool = REQUIRE_VOLUME_CONFIRM):
        self.signal_max_age = int(signal_max_age)
        self.require_perfected = False
        self.require_uptrend = bool(require_uptrend)
        self.index_bear_block = bool(index_bear_block)
        self.need_bars = int(need_bars)
        self.entry_score_min = float(entry_score_min)
        self.cooldown_days = int(cooldown_days)
        self.require_bounce = bool(require_bounce)
        self.require_volume = bool(require_volume)

    def on_init(self, context):
        context.magic_nine_stats = {
            "scanned": 0, "signals": 0, "buys": 0, "days": 0,
            "reject_trend": 0, "reject_bounce": 0, "reject_cool": 0,
            "reject_volume": 0, "path_short": 0,
        }
        context.magic_nine_cooldown = {}
        try:
            from gm.api import subscribe
            pool = list(getattr(context, "stock_pool", []) or [])
            index = getattr(config, "INDEX_SYMBOL", "SHSE.000300")
            if pool:
                subscribe(
                    symbols=pool, frequency="1d",
                    count=max(160, self.need_bars + 20),
                    fields="symbol,open,close,high,low,volume",
                    unsubscribe_previous=True,
                )
                subscribe(
                    symbols=[index], frequency="1d",
                    count=max(160, self.need_bars + 20),
                    fields="symbol,open,close,high,low,volume",
                    unsubscribe_previous=False,
                )
        except Exception as e:
            print("WARN magic_nine subscribe | %s" % e)
        print(
            "MAGIC_NINE INIT | dual_path_v63 | age<=%d | score>=%.2f | cooldown=%dd | bounce=%s | volume=%s"
            % (self.signal_max_age, self.entry_score_min, self.cooldown_days,
               self.require_bounce, self.require_volume)
        )

    def _closed_ohlcv(self, context, symbol):
        df = closed_daily_data(
            context, symbol, self.need_bars, fields="close,high,low,volume,open")
        if df is None or len(df) < 80:
            return None
        return df

    def _index_close(self, context):
        index = getattr(config, "INDEX_SYMBOL", "SHSE.000300")
        df = closed_daily_data(context, index, self.need_bars, fields="close")
        if df is None or len(df) < 60:
            return None
        try:
            return df["close"].astype(float).values
        except Exception:
            return None

    def _in_cooldown(self, context, symbol, today):
        cool = getattr(context, "magic_nine_cooldown", {}) or {}
        until = cool.get(symbol)
        if until is None:
            return False
        try:
            return today <= until
        except Exception:
            return False

    def _set_cooldown(self, context, symbol, today):
        if self.cooldown_days <= 0:
            return
        dates = getattr(context, "trading_dates_sorted", None) or []
        cool = getattr(context, "magic_nine_cooldown", None)
        if cool is None:
            context.magic_nine_cooldown = {}
            cool = context.magic_nine_cooldown
        future = [d for d in dates if d > today]
        if len(future) >= self.cooldown_days:
            cool[symbol] = future[self.cooldown_days - 1]
        else:
            cool[symbol] = today + datetime.timedelta(days=self.cooldown_days)

    def evaluate_symbol(self, context, symbol, index_close=None, today=None):
        if today is None:
            today = context.now.date()
        if self._in_cooldown(context, symbol, today):
            return None

        df = self._closed_ohlcv(context, symbol)
        if df is None:
            return None
        close = df["close"].astype(float).values
        high = df["high"].astype(float).values
        low = df["low"].astype(float).values
        volume = df["volume"].astype(float).values
        if not _finite_arr(close, high, low, volume):
            return None
        price = float(close[-1])

        ok_risk, _reason = risk_filters(close, high, low, volume, price)
        if not ok_risk:
            return None

        td = compute_td_setup(close, high, low, self.signal_max_age)
        if not td["active_buy9"]:
            return None
        if td["active_sell9"] and td["sell9_age"] <= 1:
            return None

        trend = multi_period_trend(close, index_close)
        if self.index_bear_block and trend.get("regime") == "bear":
            return None

        bounce_hard = bounce_confirm(close, float(trend.get("ma20", 0.0) or 0.0), td, soft=False)
        if not self.require_bounce:
            bounce_hard = True

        vol_score = 0.5
        vol_detail = ""
        vol_ok = True
        if self.require_volume:
            vol = volume_evaluate(close, volume, price=price, min_score=VOLUME_CONFIRM_MIN)
            vol_ok = bool(vol["ok"])
            if vol_ok:
                vol_score = float(vol["score"])
                vol_detail = " | " + vol["detail"]
            else:
                vol_detail = " | vol_fail:%s" % vol.get("reason", "?")

        score = score_signal(td, trend, vol_score=vol_score if vol_ok else 0.35)
        s_score = short_score_signal(td, trend, vol_score=vol_score if vol_ok else 0.30)

        path_a = True
        if self.require_uptrend and not trend["ok"]:
            path_a = False
        if self.require_volume and not vol_ok:
            path_a = False
        if score < self.entry_score_min:
            path_a = False
        if self.require_bounce and not bounce_hard:
            path_a = False

        path_b = False
        if vol_ok and float(vol_score) >= SHORT_VOL_MIN and trend.get("regime") != "bear":
            age_ok = (td["buy9_age"] == 0) if SHORT_REQUIRE_AGE0 else (td["buy9_age"] <= 1)
            if age_ok and float(trend.get("score", 0.0)) >= SHORT_TREND_FLOOR:
                if s_score >= SHORT_ENTRY_SCORE_MIN:
                    if bounce_confirm(close, float(trend.get("ma20", 0.0) or 0.0), td, soft=True):
                        path_b = True

        if not path_a and not path_b:
            return None

        if path_a:
            tag = "trend"
            final_score = score
        else:
            tag = "short_strong"
            final_score = max(score, s_score)

        detail = (
            "TD9 age=%d cnt=%d | %s | path=%s%s" % (
                td["buy9_age"], td["buy_count"], trend.get("detail", ""), tag, vol_detail)
        )
        return float(final_score), detail

    def scan_candidates(self, context):
        index_close = self._index_close(context)
        results = []
        scanned = 0
        stats = getattr(context, "magic_nine_stats", None)
        today = context.now.date()

        for symbol in getattr(context, "stock_pool", []) or []:
            try:
                if self._in_cooldown(context, symbol, today):
                    if isinstance(stats, dict):
                        stats["reject_cool"] = int(stats.get("reject_cool", 0)) + 1
                    continue

                df = self._closed_ohlcv(context, symbol)
                if df is None:
                    continue
                close = df["close"].astype(float).values
                high = df["high"].astype(float).values
                low = df["low"].astype(float).values
                volume = df["volume"].astype(float).values
                if not _finite_arr(close, high, low, volume):
                    continue
                scanned += 1
                price = float(close[-1])

                ok_risk, _reason = risk_filters(close, high, low, volume, price)
                if not ok_risk:
                    continue

                td = compute_td_setup(close, high, low, self.signal_max_age)
                if not td["active_buy9"]:
                    continue
                if td["active_sell9"] and td["sell9_age"] <= 1:
                    continue

                trend = multi_period_trend(close, index_close)
                if self.index_bear_block and trend.get("regime") == "bear":
                    continue

                bounce_hard = bounce_confirm(
                    close, float(trend.get("ma20", 0.0) or 0.0), td, soft=False)
                if not self.require_bounce:
                    bounce_hard = True

                vol_score = 0.5
                vol_detail = ""
                vol_ok = True
                if self.require_volume:
                    vol = volume_evaluate(
                        close, volume, price=price, min_score=VOLUME_CONFIRM_MIN)
                    vol_ok = bool(vol["ok"])
                    if vol_ok:
                        vol_score = float(vol["score"])
                        vol_detail = " | " + vol["detail"]
                    else:
                        vol_detail = " | vol_fail:%s" % vol.get("reason", "?")

                score = score_signal(td, trend, vol_score=vol_score if vol_ok else 0.35)
                s_score = short_score_signal(td, trend, vol_score=vol_score if vol_ok else 0.30)

                path_a = True
                if self.require_uptrend and not trend["ok"]:
                    path_a = False
                if self.require_volume and not vol_ok:
                    path_a = False
                if score < self.entry_score_min:
                    path_a = False
                if self.require_bounce and not bounce_hard:
                    path_a = False
                    if isinstance(stats, dict):
                        stats["reject_bounce"] = int(stats.get("reject_bounce", 0)) + 1

                path_b = False
                if vol_ok and float(vol_score) >= SHORT_VOL_MIN and trend.get("regime") != "bear":
                    age_ok = (td["buy9_age"] == 0) if SHORT_REQUIRE_AGE0 else (td["buy9_age"] <= 1)
                    if age_ok and float(trend.get("score", 0.0)) >= SHORT_TREND_FLOOR:
                        if s_score >= SHORT_ENTRY_SCORE_MIN:
                            if bounce_confirm(close, float(trend.get("ma20", 0.0) or 0.0), td, soft=True):
                                path_b = True

                if not path_a and not path_b:
                    if self.require_uptrend and not trend["ok"]:
                        if isinstance(stats, dict):
                            stats["reject_trend"] = int(stats.get("reject_trend", 0)) + 1
                    elif self.require_volume and not vol_ok:
                        if isinstance(stats, dict):
                            stats["reject_volume"] = int(stats.get("reject_volume", 0)) + 1
                    continue

                if path_a:
                    tag = "trend"
                    final_score = score
                else:
                    tag = "short_strong"
                    final_score = max(score, s_score)
                    if isinstance(stats, dict):
                        stats["path_short"] = int(stats.get("path_short", 0)) + 1
                detail = (
                    "TD9 age=%d cnt=%d | %s | path=%s%s" % (
                        td["buy9_age"], td["buy_count"], trend.get("detail", ""), tag, vol_detail)
                )
                results.append((symbol, final_score, detail))
            except Exception as e:
                print("WARN magic_nine scan | %s | %s" % (symbol, e))

        results.sort(key=lambda x: x[1], reverse=True)
        results = results[:MAX_DAILY_SIGNALS]
        if isinstance(stats, dict):
            stats["scanned"] = int(stats.get("scanned", 0)) + scanned
            stats["signals"] = int(stats.get("signals", 0)) + len(results)
            stats["days"] = int(stats.get("days", 0)) + 1
        return results

    def _get_ma(self, context, symbol, period):
        try:
            df = closed_daily_data(context, symbol, period + 2, fields="close")
            if df is None or len(df) < period:
                return None
            return float(df["close"].astype(float).values[-period:].mean())
        except Exception:
            return None

    def _get_atr(self, context, symbol):
        try:
            df = closed_daily_data(
                context, symbol, config.ATR_BARS + 2, fields="close,high,low")
            if df is None or len(df) < config.ATR_PERIOD + 1:
                return None
            c = df["close"].astype(float).values
            h = df["high"].astype(float).values
            l = df["low"].astype(float).values
            atr = _atr_series(h, l, c, config.ATR_PERIOD)
            if atr is None or not np.isfinite(atr[-1]):
                return None
            return float(atr[-1])
        except Exception:
            return None

    def _structure_stop(self, context, symbol, sl):
        try:
            df = closed_daily_data(
                context, symbol, config.STRUCT_STOP_LOOKBACK + 5, fields="low")
            return sl.calc_structure_stop(df)
        except Exception:
            return None

    def on_bar(self, context):
        import backtest_config as bt

        get_history_instruments, get_instruments, get_trading_dates = _gm()

        today = context.now.date()
        start = datetime.datetime.strptime(bt.START, "%Y-%m-%d").date()
        end = datetime.datetime.strptime(bt.END, "%Y-%m-%d").date()
        if today < start or today > end:
            return
        if context.today != today:
            context.today = today
            context.turnover_value = 0.0
        try:
            context.trading_dates_sorted = sorted(
                pd.Timestamp(x).date()
                for x in get_trading_dates(
                    exchange="SHSE", start_date=bt.START, end_date=bt.END)
            )
        except Exception:
            pass

        risk = registry.get_risk()
        sl = registry.get_sl()
        tp = registry.get_tp()

        positions = context.broker.positions()
        context.state.reconcile(positions, today)
        total_asset = context.broker.total_asset()
        if total_asset <= 0:
            return

        profile = capital_profile(total_asset)
        context.capital_profile = profile

        risk_mult = risk.on_nav(context, total_asset)
        print("RISK | date=%s | nav=%.0f | tier=%s | dd=%.2f%% | lock=%s | mult=%.2f | strategy=%s" % (
            today, total_asset, profile["tier"], context.last_dd * 100,
            context.risk_lock, risk_mult, self.NAME))

        for p in list(positions):
            symbol = p["symbol"]
            if is_st_stock(symbol, today.strftime("%Y-%m-%d")):
                try:
                    context.broker.sell_all(symbol)
                    context.turnover_value += context.broker.market_price(symbol) * int(p.get("volume", 0))
                    self._set_cooldown(context, symbol, today)
                    print("ST SELL | %s | date=%s" % (symbol, today))
                except Exception as e:
                    print("ERR ST SELL | %s | %s" % (symbol, e))
        positions = context.broker.positions()

        if risk.is_locked(context):
            if positions and context.last_dd >= config.PORTFOLIO_DD_STOP:
                for p in positions:
                    try:
                        context.broker.sell_all(p["symbol"])
                        context.turnover_value += context.broker.market_price(p["symbol"]) * int(
                            p.get("volume", 0))
                        self._set_cooldown(context, p["symbol"], today)
                        print("RISK SELL | %s | portfolio_dd=%.2f%%" % (
                            p["symbol"], context.last_dd * 100))
                    except Exception as e:
                        print("ERR RISK SELL | %s | %s" % (p["symbol"], e))
            if risk.try_unlock(context):
                print("RISK UNLOCK | benchmark trend recovered")
            else:
                print("RISK LOCK | no new positions")
                return

        for p in positions:
            symbol = p["symbol"]
            price = context.broker.market_price(symbol)
            st = context.state.get(symbol)
            if not st or price <= 0:
                continue
            st["highest"] = max(float(st.get("highest", price)), price)
            atr = self._get_atr(context, symbol)
            ma20 = self._get_ma(context, symbol, config.MA_LONG)
            held = context.state.held_days(symbol, today, context.trading_dates_sorted)

            exit_sl, reasons_sl = sl.check(
                price, float(st.get("entry_price", price)), float(st.get("highest", price)),
                atr=atr, ma20=ma20, structure_stop=st.get("structure_stop"),
                held_days=held, symbol=symbol)
            full_tp, partial_tp, reasons_tp = tp.check(
                price, float(st.get("entry_price", price)), float(st.get("highest", price)),
                already_partial=bool(st.get("partial_done", False)),
                symbol=symbol, held_days=held)

            extra = []
            if held >= 3:
                try:
                    df = self._closed_ohlcv(context, symbol)
                    if df is not None and len(df) >= 60:
                        c = df["close"].astype(float).values
                        ma60 = float(np.mean(c[-60:]))
                        ma20c = float(np.mean(c[-20:]))
                        entry = float(st.get("entry_price", price))
                        if price < ma60 * 0.98 and price < entry:
                            extra.append("structure_ma60")
                        elif held >= 8 and price < ma20c * 0.97 and price < entry * 0.98:
                            extra.append("structure_ma20")
                except Exception:
                    pass

            if exit_sl or full_tp or extra:
                reasons = list(reasons_sl) + list(reasons_tp) + extra
                try:
                    context.broker.sell_all(symbol)
                    context.turnover_value += price * int(p.get("volume", 0))
                    self._set_cooldown(context, symbol, today)
                    print("SELL | %s | %.2f | %s" % (symbol, price, ",".join(reasons)))
                except Exception as e:
                    print("ERR SELL | %s | %s" % (symbol, e))
            elif partial_tp:
                vol = int(p.get("volume", 0))
                lot_p = min_lot_size(symbol, profile["lot_size"])
                sell_vol = int(vol * tp.partial_ratio() / lot_p) * lot_p
                if sell_vol >= lot_p:
                    try:
                        context.broker.sell_volume(symbol, sell_vol)
                        context.turnover_value += price * sell_vol
                        st["partial_done"] = True
                        print("PARTIAL TP | %s | %.2f | vol=%d | %s" % (
                            symbol, price, sell_vol, ",".join(reasons_tp)))
                    except Exception as e:
                        print("ERR PARTIAL | %s | %s" % (symbol, e))

        held_positions = context.broker.positions()
        held = {p["symbol"] for p in held_positions if int(p.get("volume", 0)) > 0}
        gross = sum(float(p.get("amount", 0) or 0) for p in held_positions if int(p.get("volume", 0)) > 0)
        cash = context.broker.cash()
        if cash < total_asset * profile["min_cash_reserve_pct"] or risk_mult <= 0:
            return
        if len(held) >= profile["max_position_stock"]:
            return

        candidates = self.scan_candidates(context)
        if not candidates:
            print("NO SIGNAL | magic_nine | date=%s | pool=%d" % (
                today, len(getattr(context, "stock_pool", []) or [])))
            return

        print("SIGNS magic_nine | Top=%s" % [
            (s, round(sc, 3)) for s, sc, _ in candidates[:3]])

        buys = 0
        regime_mult = risk.regime_multiplier(context)
        if regime_mult <= 0.8:
            regime_mult = min(regime_mult, 0.65)
        effective_mult = regime_mult * risk_mult
        gross_cap = total_asset * profile["max_position_pct"] * profile["max_position_stock"]
        min_score = max(float(profile["min_buy_score"]), self.entry_score_min)

        for symbol, score, detail in candidates:
            if buys >= profile["max_daily_buy"] or symbol in held:
                continue
            if len(held) >= profile["max_position_stock"]:
                break
            if context.turnover_value >= total_asset * profile["turnover_cap"]:
                break
            if gross >= gross_cap:
                break
            if float(score) < min_score:
                continue
            if is_st_stock(symbol, today.strftime("%Y-%m-%d")):
                print("ST SKIP | %s | date=%s" % (symbol, today))
                continue
            try:
                price = context.broker.market_price(symbol)
                ins = get_instruments(symbols=symbol, skip_suspended=True, skip_st=True)
            except Exception:
                continue
            if price <= 0 or not ins:
                continue

            room = max(0.0, gross_cap - gross)
            lot = min_lot_size(symbol, profile["lot_size"])
            value = target_value(
                total_asset, float(score), effective_mult, price,
                self._get_atr(context, symbol), cash, context.turnover_value,
                gross_room=room, profile=profile, symbol=symbol, lot_size=lot)
            shares = int(value / price / lot) * lot
            if shares < lot:
                continue
            try:
                context.broker.buy(symbol, shares)
                context.turnover_value += shares * price
                cash -= shares * price
                gross += shares * price
                held.add(symbol)
                buys += 1
                context.state.items[symbol] = {
                    "entry_date": today,
                    "entry_price": price,
                    "highest": price,
                    "partial_done": False,
                    "structure_stop": self._structure_stop(context, symbol, sl),
                    "signal": "magic_nine",
                }
                stats = getattr(context, "magic_nine_stats", None)
                if isinstance(stats, dict):
                    stats["buys"] = int(stats.get("buys", 0)) + 1
                print("BUY | %s | score=%.3f | regime=%.2f | risk=%.2f | shares=%d | price=%.2f | %s" % (
                    symbol, score, regime_mult, risk_mult, shares, price, detail))
            except Exception as e:
                print("ERR BUY | %s | %s | no position opened" % (symbol, e))

    def on_order_status(self, context, order):
        pass

    def on_backtest_finished(self, context, indicator):
        stats = getattr(context, "magic_nine_stats", {})
        print("MAGIC_NINE FINISHED | stats=%s | indicator=%s" % (stats, indicator))
