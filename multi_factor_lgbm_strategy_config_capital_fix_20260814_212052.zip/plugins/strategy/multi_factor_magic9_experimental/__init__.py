# -*- coding: utf-8 -*-
from .strategy import MultiFactorMagicNineExperimentalStrategy

__all__ = ["MultiFactorMagicNineExperimentalStrategy"]
