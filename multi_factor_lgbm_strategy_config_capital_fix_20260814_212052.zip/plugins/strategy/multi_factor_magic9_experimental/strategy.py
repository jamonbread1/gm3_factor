# -*- coding: utf-8 -*-
"""Experimental strategy: MultiFactor selection + MagicNine risk overlay."""
from __future__ import annotations

import datetime
from typing import List, Tuple

from strategy.volume_confirm import evaluate as volume_evaluate

from plugins.strategy.magic_nine import MagicNineStrategy
from plugins.strategy.magic_nine.core import (
    MAX_DAILY_SIGNALS,
    VOLUME_CONFIRM_MIN,
    _finite_arr,
    multi_period_trend,
    risk_filters,
)
from plugins.strategy.multi_factor_lgbm import MultiFactorLightGBMStrategy


MFL_MAGIC9_TOP_N = 120
MFL_MAGIC9_MIN_SCORE = 0.55
MFL_MAGIC9_REQUIRE_TREND_NOT_BEAR = True
MFL_MAGIC9_REQUIRE_VOLUME = True


class MultiFactorMagicNineExperimentalStrategy(MagicNineStrategy):
    NAME = "multi_factor_magic9_experimental"

    def __init__(self, demo: bool = False, **kwargs):
        super().__init__(**kwargs)
        self.mfl = MultiFactorLightGBMStrategy(demo=demo)

    def on_init(self, context):
        self.mfl.on_init(context)
        super().on_init(context)
        print(
            "MFL_MAGIC9 EXP INIT | mfl_top=%d | min_score=%.2f | trend_not_bear=%s | volume=%s"
            % (
                MFL_MAGIC9_TOP_N,
                MFL_MAGIC9_MIN_SCORE,
                MFL_MAGIC9_REQUIRE_TREND_NOT_BEAR,
                MFL_MAGIC9_REQUIRE_VOLUME,
            )
        )

    def _mfl_candidates(self, context, today: datetime.date) -> List[str]:
        year = today.year
        if not self.mfl._ensure_model(context, year):
            return []
        ranked = self.mfl._rank_candidates(context, today, limit=MFL_MAGIC9_TOP_N)
        return [s for s, _, _ in ranked]

    def _risk_overlay_score(self, context, symbol: str, index_close, today: datetime.date):
        if self._in_cooldown(context, symbol, today):
            return None
        df = self._closed_ohlcv(context, symbol)
        if df is None or len(df) < 80:
            return None
        close = df["close"].astype(float).values
        high = df["high"].astype(float).values
        low = df["low"].astype(float).values
        volume = df["volume"].astype(float).values
        if not _finite_arr(close, high, low, volume):
            return None
        price = float(close[-1])

        ok_risk, reason = risk_filters(close, high, low, volume, price)
        if not ok_risk:
            return None

        trend = multi_period_trend(close, index_close)
        if MFL_MAGIC9_REQUIRE_TREND_NOT_BEAR and trend.get("regime") == "bear":
            return None

        vol_score = 0.5
        vol_detail = ""
        if MFL_MAGIC9_REQUIRE_VOLUME:
            vol = volume_evaluate(close, volume, price=price, min_score=VOLUME_CONFIRM_MIN)
            if not bool(vol.get("ok")):
                return None
            vol_score = float(vol.get("score", 0.5))
            vol_detail = " | " + str(vol.get("detail", "volume_ok"))

        ma20 = float(trend.get("ma20", 0.0) or 0.0)
        pullback_ok = ma20 <= 0 or price <= ma20 * 1.08
        if not pullback_ok and trend.get("regime") != "strong":
            return None

        trend_score = float(trend.get("score", 0.0) or 0.0)
        score = 0.45 + 0.35 * trend_score + 0.20 * (vol_score - 0.30)
        if trend.get("regime") == "strong":
            score += 0.06
        elif trend.get("regime") == "weak":
            score -= 0.08
        score = float(max(0.0, min(1.0, score)))
        if score < MFL_MAGIC9_MIN_SCORE:
            return None

        detail = "MFL rank + magic9 risk | %s%s | risk=%s" % (
            trend.get("detail", ""), vol_detail, reason
        )
        return score, detail

    def scan_candidates(self, context) -> List[Tuple[str, float, str]]:
        today = context.now.date()
        stats = getattr(context, "magic_nine_stats", None)
        index_close = self._index_close(context)
        mfl_ranked = self._mfl_candidates(context, today)
        if not mfl_ranked:
            return []

        results = []
        total = max(1, len(mfl_ranked) - 1)
        for rank, symbol in enumerate(mfl_ranked):
            checked = self._risk_overlay_score(context, symbol, index_close, today)
            if checked is None:
                continue
            risk_score, detail = checked
            rank_score = 1.0 - rank / total
            final_score = float(max(0.0, min(1.0, 0.65 * risk_score + 0.35 * rank_score)))
            results.append((symbol, final_score, detail))

        results.sort(key=lambda x: x[1], reverse=True)
        results = results[:MAX_DAILY_SIGNALS]
        if isinstance(stats, dict):
            stats["scanned"] = int(stats.get("scanned", 0)) + len(mfl_ranked)
            stats["signals"] = int(stats.get("signals", 0)) + len(results)
            stats["days"] = int(stats.get("days", 0)) + 1
        return results
