# RiskControl 插件接口规范

## 职责

组合层面风控：净值回撤熔断、降杠杆倍数、锁仓/解锁、市场 regime 油门。
不直接下单（锁仓后的清仓由 Strategy 根据 `is_locked` + 倍数决定）。

## 必须实现的接口

```python
class BaseRiskControl:
    NAME: str = "..."

    def on_nav(self, context, total_asset: float) -> float:
        """根据净值更新 high_water / last_dd / risk_lock，返回仓位乘数 [0, 1]。"""

    def is_locked(self, context) -> bool:
        """是否禁止新开仓（及是否应清仓由 Strategy 结合 dd 判断）。"""

    def try_unlock(self, context) -> bool:
        """尝试根据基准趋势解锁。成功返回 True。"""

    def regime_multiplier(self, context) -> float:
        """市场强弱油门，与回撤乘数相乘得到 effective_mult。"""
```

## context 约定字段（由本插件读写）

- `context.high_water`
- `context.last_dd`
- `context.risk_lock`

## 注册

```python
from plugins.risk.portfolio_dd import PortfolioDDRisk
registry.register(risk=PortfolioDDRisk())
```
