# -*- coding: utf-8 -*-
"""Portfolio drawdown circuit breaker + benchmark regime multiplier."""
import config


class PortfolioDDRisk:
    NAME = "portfolio_dd"

    def __init__(self,
                 dd_warn=None,
                 dd_deleverage=None,
                 dd_stop=None,
                 deleverage_mult=None,
                 regime_multipliers=None):
        self.dd_warn = dd_warn if dd_warn is not None else config.PORTFOLIO_DD_WARN
        self.dd_deleverage = dd_deleverage if dd_deleverage is not None else config.PORTFOLIO_DD_DELEVERAGE
        self.dd_stop = dd_stop if dd_stop is not None else config.PORTFOLIO_DD_STOP
        self.deleverage_mult = deleverage_mult if deleverage_mult is not None else config.DELEVERAGE_MULTIPLIER
        self.regime_multipliers = regime_multipliers if regime_multipliers is not None else config.REGIME_MULTIPLIERS

    def on_nav(self, context, total_asset):
        total_asset = float(total_asset or 0.0)
        hw = float(getattr(context, "high_water", total_asset) or total_asset)
        context.high_water = max(hw, total_asset)
        dd = 1.0 - total_asset / context.high_water if context.high_water > 0 else 0.0
        context.last_dd = max(0.0, dd)
        if dd >= self.dd_stop:
            context.risk_lock = True
            return 0.0
        if dd >= self.dd_deleverage:
            return float(self.deleverage_mult)
        if dd >= self.dd_warn:
            return 0.65
        return 1.0

    def is_locked(self, context):
        return bool(getattr(context, "risk_lock", False))

    def try_unlock(self, context):
        try:
            index = getattr(config, "INDEX_SYMBOL", "SHSE.000300")
            d = context.broker.history(index, 70, "close")
            c = d["close"].astype(float).values
            if len(c) < 61:
                return False
            ma20 = c[-20:].mean()
            ma60 = c[-60:].mean()
            slope = ma20 / c[-25:-5].mean() - 1
            if c[-1] > ma60 and ma20 > ma60 and slope > 0:
                context.risk_lock = False
                return True
        except Exception:
            pass
        return False

    def regime_multiplier(self, context):
        try:
            index = getattr(config, "INDEX_SYMBOL", "SHSE.000300")
            d = context.broker.history(index, 65, "close")
            c = d["close"].astype(float).values
            if len(c) < 61:
                return 1.0
            p = c[-1]
            m20 = c[-20:].mean()
            m60 = c[-60:].mean()
            slope = m20 / c[-25:-5].mean() - 1
            rm = self.regime_multipliers
            if p > m20 and m20 > m60 and slope > 0:
                return float(rm.get("strong", 1.0))
            if p > m60:
                return float(rm.get("range", 0.75))
            if p > m60 * 0.97:
                return float(rm.get("weak", 0.50))
            return float(rm.get("bear", 0.25))
        except Exception:
            return 1.0
