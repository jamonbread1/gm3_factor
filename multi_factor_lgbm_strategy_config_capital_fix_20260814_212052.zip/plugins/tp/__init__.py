# -*- coding: utf-8 -*-
from .trail_partial import TrailPartialTP

__all__ = ["TrailPartialTP"]
