# -*- coding: utf-8 -*-
"""Default take-profit: profit lock + trailing + optional partial."""
import config


class TrailPartialTP:
    NAME = "trail_partial"

    def __init__(self,
                 profit_lock_pct=None,
                 trail_stop_pct=None,
                 partial_tp_pct=None,
                 partial_ratio=None,
                 enable_partial=None):
        self.profit_lock_pct = profit_lock_pct if profit_lock_pct is not None else config.PROFIT_LOCK_PCT
        self.trail_stop_pct = trail_stop_pct if trail_stop_pct is not None else config.TRAIL_STOP_PCT
        self.partial_tp_pct = partial_tp_pct if partial_tp_pct is not None else config.PARTIAL_TP_PCT
        self._partial_ratio = partial_ratio if partial_ratio is not None else config.PARTIAL_RATIO
        self.enable_partial = enable_partial if enable_partial is not None else config.ENABLE_PARTIAL_TP

    def partial_ratio(self):
        return float(self._partial_ratio)

    def check(self, price, entry_price, highest, already_partial=False, **kwargs):
        reasons = []
        should_full = False
        should_partial = False
        if not entry_price or entry_price <= 0:
            return False, False, reasons

        profit_pct = price / entry_price - 1.0
        high_pct = (highest / entry_price - 1.0) if highest and highest > 0 else 0.0

        if high_pct >= self.profit_lock_pct and highest > 0:
            trail = highest * (1.0 - self.trail_stop_pct)
            if price < trail:
                should_full = True
                reasons.append("profit_trailing_stop")

        if self.enable_partial and (not already_partial) and profit_pct >= self.partial_tp_pct:
            should_partial = True
            reasons.append("partial_tp")

        return should_full, should_partial, reasons
