# TakeProfit 插件接口规范

## 职责

判断止盈：全平移动止盈、分批止盈。不负责下单。

## 必须实现的接口

```python
class BaseTakeProfit:
    NAME: str = "..."

    def check(self, price, entry_price, highest, already_partial=False, **kwargs):
        """
        Returns
        -------
        (should_full_exit: bool, should_partial: bool, reasons: list[str])
        """

    def partial_ratio(self) -> float:
        """分批止盈时卖出比例，默认 0.5。"""
```

## 预留 kwargs

symbol, held_days, atr, data, extra

## 注册

```python
from plugins.tp.trail_partial import TrailPartialTP
registry.register(tp=TrailPartialTP())
```
