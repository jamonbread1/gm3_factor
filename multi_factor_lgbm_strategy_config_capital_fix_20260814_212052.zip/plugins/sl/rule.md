# StopLoss 插件接口规范

## 职责

判断单票是否触发止损（硬止损 / ATR 追踪 / 结构止损 / 时间止损等）。
不负责下单，只返回 `(should_exit: bool, reasons: list[str])`。

## 必须实现的接口

```python
class BaseStopLoss:
    NAME: str = "..."

    def check(self, price, entry_price, highest, atr=None, ma20=None,
              structure_stop=None, held_days=0, data=None, **kwargs):
        """
        Returns
        -------
        (should_exit: bool, reasons: list[str])
        """

    def calc_structure_stop(self, data) -> float | None:
        """买入时调用，根据 K 线计算结构止损价。无数据返回 None。"""
```

## 预留扩展参数（kwargs）

| 键 | 类型 | 说明 |
|----|------|------|
| symbol | str | 标的 |
| today | date | 交易日 |
| volume | int | 持仓量 |
| extra | dict | 任意扩展 |

## 注册

```python
from plugins.sl.atr_structure import ATRStructureSL
registry.register(sl=ATRStructureSL())
```
