# -*- coding: utf-8 -*-
"""Default stop-loss: hard % + structure + ATR trailing + optional MA/time."""
import numpy as np
import config


class ATRStructureSL:
    NAME = "atr_structure"

    def __init__(self,
                 hard_stop_pct=None,
                 atr_stop_mult=None,
                 max_hold_days=None,
                 ma_period=None,
                 structure_lookback=None,
                 structure_buffer=None,
                 enable_ma20_exit=None):
        self.hard_stop_pct = hard_stop_pct if hard_stop_pct is not None else config.HARD_STOP_PCT
        self.atr_stop_mult = atr_stop_mult if atr_stop_mult is not None else config.ATR_STOP_MULT
        self.max_hold_days = max_hold_days if max_hold_days is not None else config.HOLD_DAYS
        self.ma_period = ma_period if ma_period is not None else config.MA_LONG
        self.structure_lookback = structure_lookback if structure_lookback is not None else config.STRUCT_STOP_LOOKBACK
        self.structure_buffer = structure_buffer if structure_buffer is not None else getattr(config, "STRUCT_STOP_BUFFER", 0.01)
        self.enable_ma20_exit = enable_ma20_exit if enable_ma20_exit is not None else config.ENABLE_MA20_EXIT

    def calc_structure_stop(self, data):
        if not config.STRUCT_STOP_ENABLE:
            return None
        if data is None or len(data) < 3:
            return None
        try:
            lows = data["low"].astype(float).values
            n = min(self.structure_lookback, len(lows))
            if n < 2:
                return None
            struct_low = float(np.min(lows[-n - 1:-1] if len(lows) > n else lows[:-1]))
            if not np.isfinite(struct_low) or struct_low <= 0:
                return None
            return struct_low * (1.0 - self.structure_buffer)
        except Exception:
            return None

    def check(self, price, entry_price, highest, atr=None, ma20=None,
              structure_stop=None, held_days=0, data=None, **kwargs):
        reasons = []
        if entry_price and entry_price > 0 and price <= entry_price * (1.0 - self.hard_stop_pct):
            reasons.append("hard_stop")
        if structure_stop and structure_stop > 0 and price <= structure_stop:
            reasons.append("structure_stop")
        if atr and atr > 0 and highest and highest > 0:
            trail = highest - self.atr_stop_mult * atr
            if price <= trail:
                reasons.append("atr_trailing_stop")
        if self.enable_ma20_exit and ma20 and price < ma20:
            reasons.append("ma20_exit")
        # Time stop only when also below MA (avoid pure churn)
        if held_days >= self.max_hold_days and ma20 and price < ma20:
            reasons.append("time_exit")
        elif held_days >= self.max_hold_days and ma20 is None and data is not None and len(data) >= self.ma_period:
            try:
                ma = float(np.mean(data["close"].astype(float).values[-self.ma_period:]))
                if price < ma:
                    reasons.append("time_exit")
            except Exception:
                pass
        return bool(reasons), reasons
