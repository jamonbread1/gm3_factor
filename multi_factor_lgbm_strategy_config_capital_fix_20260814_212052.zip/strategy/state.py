# -*- coding: utf-8 -*-
"""Strategy state. Account positions remain the source of truth; this stores derived state."""
import datetime


class PositionState:
    def __init__(self):
        self.items = {}

    def reconcile(self, positions, today):
        live = {p["symbol"]: p for p in positions if p.get("volume", 0) > 0}
        for symbol in list(self.items):
            if symbol not in live:
                del self.items[symbol]
        for symbol, pos in live.items():
            state = self.items.get(symbol)
            avg = _number(pos.get("vwap", pos.get("price", 0)))
            if not state:
                self.items[symbol] = {
                    "entry_date": today,
                    "entry_price": avg,
                    "highest": avg,
                    "partial_done": False,
                    "structure_stop": None,
                }
            elif avg > 0 and state.get("entry_price", 0) <= 0:
                state["entry_price"] = avg
            state = self.items[symbol]
            state["highest"] = max(_number(state.get("highest", avg)), _number(pos.get("price", avg)))

    def get(self, symbol):
        return self.items.get(symbol)

    def set(self, symbol, **kwargs):
        self.items.setdefault(symbol, {}).update(kwargs)

    def remove(self, symbol):
        self.items.pop(symbol, None)

    def held_days(self, symbol, today, trading_dates):
        state = self.get(symbol)
        if not state:
            return 0
        start = _date(state.get("entry_date", today))
        end = _date(today)
        return sum(1 for d in trading_dates if start < d <= end)


def _date(value):
    if isinstance(value, datetime.datetime):
        return value.date()
    if isinstance(value, datetime.date):
        return value
    return datetime.datetime.fromisoformat(str(value)).date()


def _number(v):
    try:
        return float(v or 0)
    except Exception:
        return 0.0
