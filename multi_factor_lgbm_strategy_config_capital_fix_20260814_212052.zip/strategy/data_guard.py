# -*- coding: utf-8 -*-
"""Data-safety helpers for GM3.

The strategy is scheduled at 14:50, so the current day's daily bar is not a
fully closed observation. Any signal/factor that uses OHLCV must therefore use
only bars strictly before `context.now.date()`.
"""
import datetime
import pandas as pd


def _as_date(value):
    if isinstance(value, datetime.datetime):
        return value.date()
    if isinstance(value, datetime.date):
        return value
    return pd.Timestamp(value).date()


def closed_daily_data(context, symbol, count, fields):
    """Return daily bars known before today's decision time.

    Primary guard: if the returned frame exposes an end-time/date column, filter
    rows whose bar date is strictly before today. Fallback: conservatively drop
    the newest row because GM3 context.data can contain the current in-progress
    daily bar during a 14:50 scheduled callback.
    """
    raw = context.data(symbol=symbol, frequency="1d", count=max(int(count) + 2, int(count)), fields=fields)
    if raw is None or len(raw) == 0:
        return raw
    df = raw.copy() if hasattr(raw, "copy") else pd.DataFrame(raw)
    today = _as_date(context.now)
    for col in ("eob", "bob", "created_at", "updated_at", "datetime", "date"):
        if col in df.columns:
            try:
                dates = pd.to_datetime(df[col], errors="coerce").dt.date
                filtered = df.loc[dates < today].copy()
                if len(filtered) >= count:
                    return filtered.tail(count).reset_index(drop=True)
            except Exception:
                pass
    # Fail closed against look-ahead when no timestamp is exposed.
    if len(df) > count:
        return df.iloc[:-1].tail(count).reset_index(drop=True)
    return df.iloc[:-1].reset_index(drop=True)


def previous_trading_date(context):
    try:
        from gm.api import get_previous_trading_date
        return _as_date(get_previous_trading_date(exchange="SHSE", date=context.now))
    except Exception:
        return _as_date(context.now) - datetime.timedelta(days=1)


def historical_constituent_map(index_symbol, start_date, end_date):
    """Build {trade_date: set(symbol)} from GM3 historical index constituents."""
    from gm.api import get_history_constituents
    rows = get_history_constituents(index=index_symbol, start_date=start_date, end_date=end_date)
    result = {}
    for item in rows or []:
        if isinstance(item, dict):
            date_value = item.get("trade_date", item.get("date"))
            constituents = item.get("constituents", {})
        else:
            date_value = getattr(item, "trade_date", getattr(item, "date", None))
            constituents = getattr(item, "constituents", {})
        if date_value is None:
            continue
        day = _as_date(date_value)
        if hasattr(constituents, "keys"):
            symbols = constituents.keys()
        elif isinstance(constituents, (list, tuple)):
            symbols = [x.get("symbol") if isinstance(x, dict) else getattr(x, "symbol", None) for x in constituents]
        else:
            symbols = []
        result[day] = {str(s) for s in symbols if s}
    return result
