# -*- coding: utf-8 -*-
"""Portfolio sizing + dynamic capital profile for sub-100k accounts.

capital_profile(nav) returns adaptive limits. target_value() sizes a single
entry under those limits with one-lot reachability checks.
"""
import config
from strategy.lot_rules import min_lot_size


def _lerp(a, b, t):
    t = max(0.0, min(1.0, float(t)))
    return a + (b - a) * t


def capital_profile(total_asset):
    """Adaptive portfolio parameters from current NAV.

    Designed for capital < 10万. Above 10万 gradually approaches a diversified
    institutional-style profile. Returns a plain dict used by strategy / sizing.

    Tiers (piecewise linear on key continuous fields):
      micro  < 3万   — 2 names, concentrated, stricter score, higher overshoot
      small  3–6万   — 2–3 names
      mid    6–10万  — 3 names
      large  ≥ 10万  — up to 5 names, smaller single-name weight
    """
    nav = float(total_asset or 0.0)
    if nav <= 0:
        nav = float(getattr(config, "INIT_CAPITAL", 50_000))

    if nav < 30_000:
        max_stock = 2
        max_daily = 1
        t = (nav - 20_000) / 10_000 if nav >= 20_000 else 0.0
        max_pct = _lerp(0.45, 0.38, t)
        min_pct = _lerp(0.20, 0.16, t)
        turnover = _lerp(0.65, 0.55, t)
        cash_reserve = _lerp(0.06, 0.08, t)
        min_score = _lerp(0.58, 0.56, t)
        risk_pt = _lerp(0.020, 0.018, t)
        overshoot = _lerp(1.12, 1.10, t)
        pos_mult_min = 0.55
        tier = "micro"
    elif nav < 60_000:
        max_stock = 3 if nav >= 45_000 else 2
        max_daily = 2
        t = (nav - 30_000) / 30_000
        max_pct = _lerp(0.38, 0.30, t)
        min_pct = _lerp(0.16, 0.13, t)
        turnover = _lerp(0.55, 0.48, t)
        cash_reserve = _lerp(0.08, 0.10, t)
        min_score = _lerp(0.58, 0.56, t)
        risk_pt = _lerp(0.018, 0.015, t)
        overshoot = _lerp(1.10, 1.08, t)
        pos_mult_min = 0.52
        tier = "small"
    elif nav < 100_000:
        max_stock = 3
        max_daily = 2
        t = (nav - 60_000) / 40_000
        max_pct = _lerp(0.30, 0.26, t)
        min_pct = _lerp(0.13, 0.12, t)
        turnover = _lerp(0.50, 0.45, t)
        cash_reserve = 0.10
        min_score = _lerp(0.56, 0.55, t)
        risk_pt = _lerp(0.015, 0.014, t)
        overshoot = _lerp(1.08, 1.06, t)
        pos_mult_min = 0.50
        tier = "mid"
    else:
        max_stock = 5
        max_daily = 2
        t = min(1.0, (nav - 100_000) / 400_000)
        max_pct = _lerp(0.22, 0.18, t)
        min_pct = _lerp(0.10, 0.08, t)
        turnover = _lerp(0.42, 0.38, t)
        cash_reserve = 0.10
        min_score = 0.55
        risk_pt = 0.0125
        overshoot = 1.05
        pos_mult_min = 0.45
        tier = "large"

    return {
        "tier": tier,
        "nav": nav,
        "max_position_stock": int(max_stock),
        "max_daily_buy": int(max_daily),
        "max_position_pct": float(max_pct),
        "min_position_pct": float(min_pct),
        "turnover_cap": float(turnover),
        "min_cash_reserve_pct": float(cash_reserve),
        "min_buy_score": float(min_score),
        "risk_per_trade": float(risk_pt),
        "one_lot_max_overshoot": float(overshoot),
        "pos_mult_min": float(pos_mult_min),
        "score_full_cap": float(getattr(config, "SCORE_FULL_CAP", 0.85)),
        "lot_size": int(getattr(config, "LOT_SIZE", 100)),
    }


def score_multiplier(score, profile=None):
    if profile is None:
        lo = getattr(config, "MIN_BUY_SCORE", 0.60)
        hi = getattr(config, "SCORE_FULL_CAP", 0.85)
        pmin = getattr(config, "POS_MULT_MIN", 0.50)
    else:
        lo = profile["min_buy_score"]
        hi = profile["score_full_cap"]
        pmin = profile["pos_mult_min"]
    span = max(hi - lo, 1e-9)
    x = max(0.0, min(1.0, (float(score) - lo) / span))
    return pmin + (1.0 - pmin) * x


def target_value(total_asset, score, regime_multiplier=1.0, price=0.0,
                 atr=None, cash=None, turnover_used=0.0,
                 max_position_pct=None, gross_room=None, profile=None,
                 symbol=None, lot_size=None):
    """Executable notional for one new position.

    If symbol is provided, lot_size is resolved via board rules (科创板 200).
    """
    if total_asset <= 0 or price <= 0:
        return 0.0

    if profile is None:
        profile = capital_profile(total_asset)

    if lot_size is None:
        base_lot = int(profile.get("lot_size", getattr(config, "LOT_SIZE", 100)))
        lot = min_lot_size(symbol, base_lot) if symbol else base_lot
    else:
        lot = int(lot_size)

    max_pct = float(max_position_pct if max_position_pct is not None else profile["max_position_pct"])
    overshoot = float(profile["one_lot_max_overshoot"])
    turnover_cap = float(profile["turnover_cap"])
    risk_pt = float(profile["risk_per_trade"])
    min_score = float(profile["min_buy_score"])

    if float(score) < min_score:
        return 0.0

    one_lot = price * lot
    regime = max(0.0, float(regime_multiplier))
    slot_cap = total_asset * max_pct * regime
    if one_lot > slot_cap * overshoot:
        return 0.0

    value = total_asset * max_pct * score_multiplier(score, profile) * regime
    if gross_room is not None:
        value = min(value, max(0.0, gross_room))
    if cash is not None:
        value = min(value, max(0.0, cash))
    if atr and atr > 0:
        risk_value = total_asset * risk_pt * price / atr
        value = min(value, risk_value)
    remaining_turnover = max(0.0, total_asset * turnover_cap - max(0.0, turnover_used))
    value = min(value, remaining_turnover)

    if value < one_lot:
        if cash is not None and one_lot <= cash and one_lot <= slot_cap * overshoot:
            if gross_room is None or one_lot <= gross_room:
                return one_lot
        return 0.0

    shares = int(value / price / lot) * lot
    return max(0.0, shares * price)
