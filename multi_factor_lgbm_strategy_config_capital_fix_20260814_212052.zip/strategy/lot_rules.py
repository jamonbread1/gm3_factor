# -*- coding: utf-8 -*-
"""A-share board lot rules for GM3 market orders.

主板 / 创业板 市价单通常 100 股起；科创板（SHSE.688xxx）市价申报单笔不少于 200 股。
北交所常见 100 股，但以交易所规则为准，这里保守按 100。

Used by portfolio sizing and broker.buy guard so ORDER FAIL status=8
(科创板 <200) does not waste a slot.
"""
from __future__ import annotations

DEFAULT_LOT = 100
STAR_LOT = 200  # 科创板市价申报下限


def min_lot_size(symbol: str, default: int = DEFAULT_LOT) -> int:
    """Return minimum order volume (shares) for market order on this symbol."""
    s = str(symbol or "").upper().strip()
    code = s.split(".")[-1] if "." in s else s
    # STAR Market (Science & Technology Innovation Board)
    if code.startswith("688") or s.startswith("SHSE.688"):
        return STAR_LOT
    # default A-share board lot
    return int(default) if default and default > 0 else DEFAULT_LOT


def round_lot(volume: int, symbol: str, default: int = DEFAULT_LOT) -> int:
    """Floor volume to a multiple of the board lot; 0 if below minimum."""
    lot = min_lot_size(symbol, default)
    volume = int(volume or 0)
    if volume < lot:
        return 0
    return (volume // lot) * lot
