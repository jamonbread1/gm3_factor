# strategy/ 工具包说明

本目录 **不是** 可拔插策略插件（插件在 `plugins/strategy/`）。

| 文件 | 职责 |
|------|------|
| `state.py` | `PositionState`：入场价、最高价、结构止损、持仓天数 |
| `portfolio.py` | `capital_profile` / `target_value`：按净值动态仓位 |
| `data_guard.py` | 避免 14:50 用到未收盘日 K 的前瞻偏差 |

## 动态资金档位 `capital_profile(nav)`

| 档位 | 净值 | 持仓数 | 单仓上限约 | 说明 |
|------|------|--------|------------|------|
| micro | <3万 | 2 | 38–45% | 极致集中，分数门槛更高 |
| small | 3–6万 | 2–3 | 30–38% | 默认多数实盘区间 |
| mid | 6–10万 | 3 | 26–30% | 略分散 |
| large | ≥10万 | 5 | →18% | 逐步接近经典配置 |

连续字段（单仓%、换手、风险预算等）在档位内线性插值。

## 仓位接口

```python
profile = capital_profile(total_asset)
target_value(total_asset, score, regime_multiplier, price, atr, cash,
             turnover_used, profile=profile) -> float
```
