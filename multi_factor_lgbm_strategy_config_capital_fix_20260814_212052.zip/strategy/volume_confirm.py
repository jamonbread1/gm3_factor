# -*- coding: utf-8 -*-
"""Shared volume / price-volume confirmation metrics.

Adapted from QuantSkills skill-quant-factor-volume-stat-alpha formulas
(volume_ratio, obv_slope, price_volume_corr, dollar_volume activity)
for single-symbol scoring on closed daily bars.

Design for live research (周级趋势跟踪 on daily data):
  - Primary window 10 trading days ≈ one week confirmation
  - Secondary 5d for freshness
  - Hard filter (ok/reason) separate from soft score [0,1]
  - Pure functions, no gm.api, no future bars

Placed under strategy/ (not select/) to avoid clash with Python stdlib `select`.
"""
from __future__ import annotations

from typing import Any, Dict, Optional, Tuple

import numpy as np

# Week-oriented defaults (trading days)
W_FAST = 5
W_WEEK = 10
W_SLOW = 20
NORM = 20

MIN_AVG_AMOUNT = 2.5e6
MIN_VOLUME_RATIO_5_20 = 0.75
MIN_OBV_SLOPE_Z = -1.25
MIN_CONFIRM_SCORE = 0.35


def _minp(window: int, floor: int = 5) -> int:
    return min(window, max(2, min(floor, window // 2 if window > 2 else 2)))


def _zscore_last(series: np.ndarray, window: int) -> float:
    if series is None or len(series) < max(3, window // 2):
        return float("nan")
    w = min(window, len(series))
    seg = series[-w:]
    m = float(np.nanmean(seg))
    s = float(np.nanstd(seg))
    if not np.isfinite(s) or s < 1e-12:
        return 0.0
    return float((seg[-1] - m) / s)


def _rolling_slope_last(series: np.ndarray, window: int) -> float:
    window = max(3, int(window))
    if series is None or len(series) < window:
        return float("nan")
    y = series[-window:].astype(float)
    if not np.all(np.isfinite(y)):
        return float("nan")
    x = np.arange(window, dtype=float)
    x = x - x.mean()
    denom = float(np.sum(x * x))
    if denom <= 0:
        return 0.0
    y = y - y.mean()
    return float(np.sum(x * y) / denom)


def volume_ratio(volume: np.ndarray, window: int = W_WEEK) -> float:
    if volume is None or len(volume) < window:
        return float("nan")
    base = float(np.mean(volume[-window:]))
    if base <= 0:
        return float("nan")
    return float(volume[-1] / base - 1.0)


def volume_expansion_z(volume: np.ndarray, window: int = W_WEEK, norm: int = NORM) -> float:
    if volume is None or len(volume) < max(window, norm // 2):
        return float("nan")
    n = len(volume)
    ratios = np.full(n, np.nan)
    for i in range(window - 1, n):
        m = float(np.mean(volume[i - window + 1:i + 1]))
        if m > 0:
            ratios[i] = volume[i] / m - 1.0
    finite = ratios[np.isfinite(ratios)]
    if len(finite) < 3:
        return float("nan")
    return _zscore_last(finite, min(norm, len(finite)))


def obv_series(close: np.ndarray, volume: np.ndarray) -> np.ndarray:
    n = len(close)
    out = np.zeros(n, dtype=float)
    if n == 0:
        return out
    out[0] = float(volume[0]) if np.isfinite(volume[0]) else 0.0
    for i in range(1, n):
        d = close[i] - close[i - 1]
        sign = 1.0 if d > 0 else (-1.0 if d < 0 else 0.0)
        v = float(volume[i]) if np.isfinite(volume[i]) else 0.0
        out[i] = out[i - 1] + sign * v
    return out


def obv_slope_z(close: np.ndarray, volume: np.ndarray,
                window: int = W_WEEK, norm: int = NORM) -> float:
    if close is None or volume is None or len(close) < window + 2:
        return float("nan")
    obv = obv_series(close, volume)
    vol_ma = float(np.mean(volume[-window:]))
    if vol_ma <= 0:
        return float("nan")
    slopes = []
    max_i = len(obv)
    start = max(window, max_i - norm - window)
    for i in range(start, max_i + 1):
        if i < window:
            continue
        seg = obv[i - window:i]
        if len(seg) < window or not np.all(np.isfinite(seg)):
            continue
        slopes.append(_rolling_slope_last(seg, window) / vol_ma)
    if not slopes:
        return float("nan")
    arr = np.asarray(slopes, dtype=float)
    return _zscore_last(arr, min(norm, len(arr)))


def price_volume_corr(close: np.ndarray, volume: np.ndarray, window: int = W_WEEK) -> float:
    if close is None or volume is None or len(close) < window + 1:
        return float("nan")
    ret = np.diff(close.astype(float)) / np.where(close[:-1] == 0, np.nan, close[:-1])
    vch = np.diff(volume.astype(float)) / np.where(volume[:-1] == 0, np.nan, volume[:-1])
    if len(ret) < window:
        return float("nan")
    r = ret[-window:]
    v = vch[-window:]
    mask = np.isfinite(r) & np.isfinite(v)
    if np.sum(mask) < max(5, window // 2):
        return float("nan")
    r, v = r[mask], v[mask]
    if np.std(r) < 1e-12 or np.std(v) < 1e-12:
        return 0.0
    return float(np.corrcoef(r, v)[0, 1])


def dollar_volume_activity(close: np.ndarray, volume: np.ndarray, window: int = W_WEEK) -> float:
    if close is None or volume is None or len(close) < window:
        return float("nan")
    dollar = close.astype(float) * volume.astype(float)
    m = float(np.mean(dollar[-window:]))
    if m <= 0:
        return float("nan")
    return float(dollar[-1] / m - 1.0)


def avg_amount(close: np.ndarray, volume: np.ndarray, window: int = W_SLOW) -> float:
    if close is None or volume is None or len(close) < window:
        return 0.0
    return float(np.mean(volume[-window:]) * close[-1])


def volume_ratio_5_20(volume: np.ndarray) -> float:
    if volume is None or len(volume) < W_SLOW:
        return float("nan")
    v5 = float(np.mean(volume[-W_FAST:]))
    v20 = float(np.mean(volume[-W_SLOW:]))
    if v20 <= 0:
        return float("nan")
    return v5 / v20


def clip01(x: float) -> float:
    if not np.isfinite(x):
        return 0.0
    return float(max(0.0, min(1.0, x)))


def confirm_metrics(close: np.ndarray, volume: np.ndarray,
                    price: Optional[float] = None) -> Dict[str, float]:
    if price is None and close is not None and len(close):
        price = float(close[-1])
    price = float(price or 0.0)
    return {
        "vol_exp_z_10": volume_expansion_z(volume, W_WEEK, NORM),
        "vol_exp_z_5": volume_expansion_z(volume, W_FAST, NORM),
        "obv_z_10": obv_slope_z(close, volume, W_WEEK, NORM),
        "obv_z_5": obv_slope_z(close, volume, W_FAST, NORM),
        "pv_corr_10": price_volume_corr(close, volume, W_WEEK),
        "dvol_act_10": dollar_volume_activity(close, volume, W_WEEK),
        "vr_5_20": volume_ratio_5_20(volume),
        "avg_amt_20": avg_amount(close, volume, W_SLOW),
        "price": price,
    }


def hard_filter(metrics: Dict[str, float],
                min_avg_amount: float = MIN_AVG_AMOUNT,
                min_vr: float = MIN_VOLUME_RATIO_5_20,
                min_obv_z: float = MIN_OBV_SLOPE_Z) -> Tuple[bool, str]:
    amt = metrics.get("avg_amt_20", 0.0)
    if not np.isfinite(amt) or amt < min_avg_amount:
        return False, "liquidity"
    vr = metrics.get("vr_5_20", float("nan"))
    if not np.isfinite(vr) or vr < min_vr:
        return False, "volume_dry"
    obv = metrics.get("obv_z_10", float("nan"))
    if np.isfinite(obv) and obv < min_obv_z:
        return False, "obv_divergent"
    return True, "ok"


def soft_score(metrics: Dict[str, float]) -> float:
    def nz(key, default=0.0):
        v = metrics.get(key, default)
        return float(v) if np.isfinite(v) else default

    def z01(z):
        return clip01((z + 1.5) / 3.0)

    vol10 = z01(nz("vol_exp_z_10"))
    vol5 = z01(nz("vol_exp_z_5"))
    obv10 = z01(nz("obv_z_10"))
    obv5 = z01(nz("obv_z_5"))
    pvc = nz("pv_corr_10")
    pvc01 = clip01((pvc + 0.3) / 0.8)
    dvol = nz("dvol_act_10")
    dvol01 = clip01((dvol + 0.2) / 0.8)

    score = (
        0.30 * vol10
        + 0.30 * obv10
        + 0.20 * pvc01
        + 0.05 * vol5
        + 0.05 * obv5
        + 0.10 * dvol01
    )
    return clip01(score)


def evaluate(close: np.ndarray, volume: np.ndarray,
             price: Optional[float] = None,
             min_score: float = MIN_CONFIRM_SCORE) -> Dict[str, Any]:
    m = confirm_metrics(close, volume, price)
    ok, reason = hard_filter(m)
    score = soft_score(m) if ok else 0.0
    if ok and score < min_score:
        ok, reason = False, "confirm_low"
        score = 0.0
    detail = (
        "VE10:%.2f OBV10:%.2f PVC:%.2f VR:%.2f conf:%.2f"
        % (m.get("vol_exp_z_10", float("nan")),
           m.get("obv_z_10", float("nan")),
           m.get("pv_corr_10", float("nan")),
           m.get("vr_5_20", float("nan")),
           score)
    )
    return {
        "ok": bool(ok),
        "reason": reason,
        "score": float(score),
        "metrics": m,
        "detail": detail,
    }
