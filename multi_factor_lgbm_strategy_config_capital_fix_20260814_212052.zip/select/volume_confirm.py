# -*- coding: utf-8 -*-
"""Deprecated path. Use strategy.volume_confirm (avoids clash with stdlib `select`)."""
from strategy.volume_confirm import *  # noqa: F401,F403
from strategy.volume_confirm import evaluate, MIN_CONFIRM_SCORE  # noqa: F401
