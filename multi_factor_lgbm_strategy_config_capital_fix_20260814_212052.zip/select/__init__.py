# -*- coding: utf-8 -*-
"""Factor registry with configurable weights and rank / raw synthesis."""
from . import factor_01_rps
from . import factor_02_three_layer
from . import factor_03_v4_alpha
from . import factor_04_volume_stat

# Register factors. Each entry is a module OR (module, weight_override).
# Only factors that all return non-None for a symbol participate in ranking.
#
# Live-research default: primary trend alpha + volume confirmation (week-scale).
# Uncomment other factors only after IC / turnover checks on your universe.
FACTORS = [
    factor_03_v4_alpha,
    (factor_04_volume_stat, 0.35),
    # factor_01_rps,
    # (factor_01_rps, 0.25),
]

# "rank" = cross-sectional percentile ranks then weighted average (recommended)
# "raw"  = weighted average of raw scores (legacy)
WEIGHT_MODE = "rank"

INDEX_SYMBOL = "SHSE.000300"
TOP_N = 10
FETCH_FIELDS = "close,volume,high,low"


class FactorContext:
    __slots__ = ("symbol", "stock", "index", "index_close", "total_asset", "today", "extra")

    def __init__(self, symbol, stock, index, total_asset, today=None, extra=None):
        self.symbol = symbol
        self.stock = stock
        self.index = index
        self.index_close = index["close"].values if index is not None else None
        self.total_asset = total_asset
        self.today = today
        self.extra = extra or {}


def _iter_factors():
    """Yield (module, weight)."""
    for entry in FACTORS:
        if isinstance(entry, tuple):
            mod, w = entry[0], float(entry[1])
        else:
            mod, w = entry, float(getattr(entry, "WEIGHT", 1.0))
        yield mod, w


def _rank_scores(raw_list):
    """raw_list: list of float. Return list of percentile ranks in [0, 1].

    Ties get average rank. Single element -> 1.0.
    """
    n = len(raw_list)
    if n == 0:
        return []
    if n == 1:
        return [1.0]
    order = sorted(range(n), key=lambda i: raw_list[i])
    ranks = [0.0] * n
    i = 0
    while i < n:
        j = i
        while j + 1 < n and raw_list[order[j + 1]] == raw_list[order[i]]:
            j += 1
        # average rank of ties, then scale to [0, 1]
        avg = (i + j) / 2.0
        scaled = avg / (n - 1) if n > 1 else 1.0
        for k in range(i, j + 1):
            ranks[order[k]] = scaled
        i = j + 1
    return ranks


def get_strong_stocks(context, today=None, total_asset=None):
    factor_list = list(_iter_factors())
    if not factor_list:
        return []

    idx_need = max(getattr(f, "IDX_NEED_BARS", 70) for f, _ in factor_list)
    idx_data = context.data(symbol=INDEX_SYMBOL, frequency="1d", count=idx_need, fields="close")
    if idx_data is None or len(idx_data) == 0:
        return []

    bars_need = max(getattr(f, "NEED_BARS", 80) for f, _ in factor_list)
    bars_min = min(getattr(f, "MIN_BARS", 70) for f, _ in factor_list)

    # Collect per-symbol factor results: symbol -> {factor_name: (score, detail, weight)}
    per_symbol = {}
    for sym in context.stock_pool:
        try:
            data = context.data(symbol=sym, frequency="1d", count=bars_need, fields=FETCH_FIELDS)
            if data is None or len(data) < bars_min:
                continue
            fctx = FactorContext(sym, data, idx_data, total_asset, today)
            results = {}
            veto = False
            details = []
            for factor, weight in factor_list:
                result = factor.score_stock(fctx)
                if result is None:
                    veto = True
                    break
                name = getattr(factor, "NAME", factor.__name__ if hasattr(factor, "__name__") else str(factor))
                results[name] = (float(result["score"]), str(result.get("detail", "")), weight)
                details.append(str(result.get("detail", "")))
            if veto or not results:
                continue
            per_symbol[sym] = {"results": results, "details": details}
        except Exception as e:
            print("WARN factor %s: %s" % (sym, e))

    if not per_symbol:
        return []

    names = list(per_symbol.keys())

    if WEIGHT_MODE == "raw":
        scores = []
        for sym in names:
            acc = 0.0
            tw = 0.0
            for _name, (sc, _d, w) in per_symbol[sym]["results"].items():
                acc += sc * w
                tw += w
            final = acc / tw if tw > 0 else 0.0
            detail = " ".join(per_symbol[sym]["details"])
            scores.append((sym, final, detail))
    else:
        # rank mode: percentile rank per factor, then weighted average
        factor_names = []
        weights = {}
        # stable factor order from first symbol (all have same keys if no veto)
        sample = next(iter(per_symbol.values()))["results"]
        for fname, (_sc, _d, w) in sample.items():
            factor_names.append(fname)
            weights[fname] = w

        rank_table = {fname: {} for fname in factor_names}
        for fname in factor_names:
            raw = []
            syms = []
            for sym in names:
                if fname not in per_symbol[sym]["results"]:
                    continue
                raw.append(per_symbol[sym]["results"][fname][0])
                syms.append(sym)
            ranks = _rank_scores(raw)
            for sym, r in zip(syms, ranks):
                rank_table[fname][sym] = r

        scores = []
        for sym in names:
            acc = 0.0
            tw = 0.0
            for fname in factor_names:
                r = rank_table[fname].get(sym)
                if r is None:
                    continue
                w = weights[fname]
                acc += r * w
                tw += w
            final = acc / tw if tw > 0 else 0.0
            detail = " ".join(per_symbol[sym]["details"])
            # annotate rank composite lightly
            detail = ("rank:%.3f " % final) + detail
            scores.append((sym, final, detail))

    scores.sort(key=lambda x: x[1], reverse=True)
    if scores:
        print("SIGNS | mode=%s | Top3=%s" % (
            WEIGHT_MODE, [(x[0], round(x[1], 3)) for x in scores[:3]]))
    return scores[:TOP_N]
