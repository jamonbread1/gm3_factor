# -*- coding: utf-8 -*-
"""
因子02：三层选股模型 V3（按 1.txt 方法论完整实现）

    第一层  Alpha 找强者        RS20/RS60/动量 + 趋势质量(连续评分, 不做死硬过滤)
    第二层  真上涨 vs 假反弹     Fake Rebound Detector(强烈降权) + 真突破小幅奖励
    第三层  可交易性 + 风险控制   ATR风险 + 市场Regime连续油门 + 小资金仓位效率

原则（来自方法论文档）：
  * factor 只负责选股评分, 输出可解释 dict; "买多少"由 main 的仓位模块决定
    （Alpha决定仓位上限, ATR决定仓位调整）
  * 趋势不做全硬过滤: 轻微跌破MA20扣分, 严重跌破才淘汰
  * ATR 不杀 Alpha: 高Alpha高波动 → 可以买但仓位小
  * 市场 Regime 是连续风险油门(1.0/0.9/0.75/0.6), 不清仓不关闸
  * 假反弹结构强烈降权(×0.6)而非直接淘汰

A/B 对照：在 select/__init__.py 的 FACTORS 中切换 factor_01_rps / 本因子即可。
"""
import numpy as np

NAME = "三层选股模型V3"
WEIGHT = 1.0

NEED_BARS = 80          # 个股取数长度（>=70 才评分）
MIN_BARS = 70
IDX_NEED_BARS = 70      # 指数取数长度（MA60+斜率需要）

# ==================== 参数（1.txt 推荐默认值） ====================
MIN_PRICE = 3.0             # 基础过滤：最低股价
MIN_AVG_AMOUNT = 3e6        # 流动性：20日日均成交额下限
MIN_VOLUME_RATIO = 0.80     # 流动性：5日均量/20日均量
MAX_ATR_PCT = 0.12          # ATR/价格 超过直接淘汰
MIN_SCORE = 0.55            # 最终分门槛
LOT_SIZE = 100              # 一手股数
CAPITAL_TARGET_PCT = 0.18   # 资金适配的目标单仓占比（与 MAX_POSITION_PCT 一致）


def _clip(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))


def _market_multiplier(index_close):
    """市场 Regime：连续风险油门，不清仓不关闸（1.txt 第二十二节）"""
    if index_close is None or len(index_close) < 65:
        return 1.0
    idx_price = float(index_close[-1])
    idx_ma20 = float(np.mean(index_close[-20:]))
    idx_ma60 = float(np.mean(index_close[-60:]))
    base = float(np.mean(index_close[-25:-5]))
    idx_ma20_slope = idx_ma20 / base - 1 if base > 0 else 0.0

    if idx_price > idx_ma20 and idx_ma20 > idx_ma60 and idx_ma20_slope > 0:
        return 1.00     # 强市场
    elif idx_price > idx_ma60:
        return 0.90     # 震荡
    elif idx_price > idx_ma60 * 0.97:
        return 0.75     # 弱市场
    else:
        return 0.60     # 熊市（仍允许交易，只压分）


def score_stock(fctx):
    """对单只股票评分。

    fctx: select/__init__.py 构造的 FactorContext
        fctx.stock        个股日线 DataFrame(close/high/low/volume)
        fctx.index_close  指数收盘价 ndarray
        fctx.total_asset  账户总资产（None 时跳过资金适配层）
    返回可解释 dict（含 'score'/'detail'），不符合条件返回 None。
    """
    data = fctx.stock
    index_close = fctx.index_close
    total_asset = fctx.total_asset

    # ============ 01 基础过滤 ============
    if data is None or len(data) < MIN_BARS:
        return None
    try:
        close = data["close"].astype(float).values
        high = data["high"].astype(float).values
        low = data["low"].astype(float).values
        volume = data["volume"].astype(float).values
    except Exception:
        return None
    if not (np.all(np.isfinite(close)) and np.all(np.isfinite(high))
            and np.all(np.isfinite(low)) and np.all(np.isfinite(volume))):
        return None

    price = float(close[-1])
    if price <= 0 or price < MIN_PRICE:
        return None

    # ============ 02 流动性 ============
    avg_amount20 = float(np.mean(volume[-20:])) * price
    if avg_amount20 < MIN_AVG_AMOUNT:
        return None
    vol20 = float(np.mean(volume[-20:]))
    vol5 = float(np.mean(volume[-5:]))
    volume_ratio = vol5 / vol20 if vol20 > 0 else 0.0
    if volume_ratio < MIN_VOLUME_RATIO:
        return None

    # ============ 03 均线与斜率 ============
    ma5 = float(np.mean(close[-5:]))
    ma20 = float(np.mean(close[-20:]))
    ma60 = float(np.mean(close[-60:]))
    ma20_prev = float(np.mean(close[-25:-5]))
    ma60_prev = float(np.mean(close[-70:-10]))
    ma20_slope = ma20 / ma20_prev - 1 if ma20_prev > 0 else 0.0
    ma60_slope = ma60 / ma60_prev - 1 if ma60_prev > 0 else 0.0

    # ============ 04 弱趋势硬过滤（只淘汰严重走坏，不做死过滤） ============
    if price < ma20 * 0.96:
        return None
    if ma20 < ma60 * 0.97:
        return None

    # ============ 05 相对强度 ============
    if index_close is None or len(index_close) < 61:
        return None
    ret20 = price / close[-20] - 1
    ret60 = price / close[-60] - 1
    idx_ret20 = index_close[-1] / index_close[-20] - 1
    idx_ret60 = index_close[-1] / index_close[-60] - 1
    excess20 = ret20 - idx_ret20
    excess60 = ret60 - idx_ret60

    rs20_score = _clip((excess20 + 0.05) / 0.15)
    rs60_score = _clip((excess60 + 0.10) / 0.30)

    # ============ 06 短期动量（含暴涨保护） ============
    ret5 = price / close[-5] - 1
    ret10 = price / close[-10] - 1
    momentum_score = 0.0
    if ret5 > 0:
        momentum_score += 0.30
    if ret5 > 0.03:
        momentum_score += 0.20
    if ret10 > 0:
        momentum_score += 0.30
    if ret10 > 0.05:
        momentum_score += 0.20
    momentum_score = _clip(momentum_score)
    if ret5 > 0.15:
        momentum_score *= 0.75
    elif ret5 > 0.10:
        momentum_score *= 0.90

    # ============ 07 趋势质量（连续评分） ============
    trend_score = 0.0
    if price > ma5:
        trend_score += 0.15
    if price > ma20:
        trend_score += 0.25
    elif price > ma20 * 0.98:
        trend_score += 0.10
    if ma20 > ma60:
        trend_score += 0.25
    elif ma20 > ma60 * 0.98:
        trend_score += 0.10
    if ma20_slope > 0.03:
        trend_score += 0.20
    elif ma20_slope > 0:
        trend_score += 0.12
    if ma60_slope > 0:
        trend_score += 0.15
    trend_score = _clip(trend_score)

    # ============ 08 Recovery Ratio + 前高距离 ============
    high20 = float(np.max(high[-20:]))
    low20 = float(np.min(low[-20:]))
    price_range = high20 - low20
    recovery_ratio = (price - low20) / (price_range + 1e-8)
    distance_high20 = price / high20 - 1 if high20 > 0 else 0.0

    if recovery_ratio < 0.35:
        recovery_score = 0.30
    elif recovery_ratio < 0.55:
        recovery_score = 0.55
    elif recovery_ratio < 0.75:
        recovery_score = 0.80
    elif recovery_ratio < 0.90:
        recovery_score = 1.00
    else:
        recovery_score = 0.90     # 过高可能在加速冲顶，不盲目给满

    # ============ 09 量能确认（上涨放量/下跌缩量） ============
    up_volume, down_volume = [], []
    n = len(close)
    for i in range(n - 10, n):
        if close[i] > close[i - 1]:
            up_volume.append(volume[i])
        elif close[i] < close[i - 1]:
            down_volume.append(volume[i])
    avg_up_volume = float(np.mean(up_volume)) if up_volume else 0.0
    avg_down_volume = float(np.mean(down_volume)) if down_volume else 1.0
    volume_confirmation = avg_up_volume / (avg_down_volume + 1e-8)

    if volume_confirmation > 1.30:
        volume_confirm_score = 1.00
    elif volume_confirmation > 1.05:
        volume_confirm_score = 0.80
    elif volume_confirmation > 0.85:
        volume_confirm_score = 0.55
    else:
        volume_confirm_score = 0.25

    # ============ 10 ATR 风险（不杀Alpha，只压分/极端淘汰） ============
    tr = np.maximum(high[1:] - low[1:],
                    np.maximum(np.abs(high[1:] - close[:-1]),
                               np.abs(low[1:] - close[:-1])))
    atr = float(np.mean(tr[-14:]))
    atr_pct = atr / price if price > 0 else 9.9
    if atr_pct > MAX_ATR_PCT:
        return None

    if atr_pct > 0.10:
        risk_score = 0.50
    elif atr_pct > 0.08:
        risk_score = 0.70
    elif atr_pct > 0.05:
        risk_score = 0.90
    else:
        risk_score = 1.00

    # ============ 11 Fake Rebound Detector ============
    rebound_risk = 0.0
    if excess20 > 0.08 and excess60 < -0.05:
        rebound_risk += 0.30          # 短强中长弱
    if ma20_slope < -0.02:
        rebound_risk += 0.25          # MA20 下降
    if ma20_slope < -0.02 and ma60_slope < 0:
        rebound_risk += 0.20          # MA20/MA60 双双下降
    if distance_high20 < -0.20:
        rebound_risk += 0.25          # 距前高太远
    elif distance_high20 < -0.15:
        rebound_risk += 0.15
    if volume_confirm_score < 0.55:
        rebound_risk += 0.15          # 反弹无量
    rebound_risk = _clip(rebound_risk)
    rebound_quality = 1.0 - rebound_risk

    # ============ 12 基础 Alpha 合成 ============
    alpha_score = (
        rs20_score * 0.30
        + rs60_score * 0.15
        + trend_score * 0.20
        + recovery_score * 0.15
        + momentum_score * 0.10
        + volume_confirm_score * 0.05
        + risk_score * 0.05
    )

    # ============ 13 假反弹降权（强烈降权而非淘汰） ============
    alpha_score *= rebound_quality
    fake_rebound = (
        excess20 > 0.08
        and excess60 < -0.05
        and ma20_slope < 0
        and recovery_ratio < 0.70
    )
    if fake_rebound:
        alpha_score *= 0.60

    # ============ 14 真突破小幅奖励（只+5%，防追涨） ============
    true_breakout = (
        excess20 > 0.08
        and excess60 > 0.05
        and ma20_slope > 0
        and ma60_slope >= 0
        and price >= high20 * 0.98
        and volume_confirm_score >= 0.80
    )
    if true_breakout:
        alpha_score *= 1.05

    # ============ 15 市场 Regime ============
    market_multiplier = _market_multiplier(index_close)
    alpha_score *= market_multiplier

    # ============ 16 小资金仓位效率 ============
    if total_asset and total_asset > 0:
        target_value = total_asset * CAPITAL_TARGET_PCT
        one_lot_value = price * LOT_SIZE
        lots = int(target_value / one_lot_value) if one_lot_value > 0 else 0
        actual_value = lots * one_lot_value
        position_efficiency = actual_value / target_value if target_value > 0 else 0.0
    else:
        position_efficiency = 1.0     # 未知资金规模时不参与压分

    if position_efficiency >= 0.90:
        capital_score = 1.00
    elif position_efficiency >= 0.75:
        capital_score = 0.90
    elif position_efficiency >= 0.60:
        capital_score = 0.75
    elif position_efficiency >= 0.40:
        capital_score = 0.55
    elif position_efficiency > 0:
        capital_score = 0.30
    else:
        capital_score = 0.05

    # ============ 17 最终评分 ============
    final_score = _clip(alpha_score * 0.85 + capital_score * 0.15)
    if final_score < MIN_SCORE:
        return None

    detail = (f"RS20:{excess20:+.1%} RS60:{excess60:+.1%} 趋势:{trend_score:.2f} "
              f"反弹质量:{rebound_quality:.2f} 市场:{market_multiplier:.2f}")
    return {
        "score": float(final_score),
        "detail": detail,
        "alpha_score": float(alpha_score),
        "capital_score": float(capital_score),
        "rs20": float(excess20),
        "rs60": float(excess60),
        "ret5": float(ret5),
        "ret20": float(ret20),
        "ret60": float(ret60),
        "trend_score": float(trend_score),
        "recovery_ratio": float(recovery_ratio),
        "distance_high20": float(distance_high20),
        "volume_ratio": float(volume_ratio),
        "volume_confirmation": float(volume_confirmation),
        "atr": float(atr),
        "atr_pct": float(atr_pct),
        "rebound_risk": float(rebound_risk),
        "market_multiplier": float(market_multiplier),
        "position_efficiency": float(position_efficiency),
        "fake_rebound": bool(fake_rebound),
        "true_breakout": bool(true_breakout),
    }
