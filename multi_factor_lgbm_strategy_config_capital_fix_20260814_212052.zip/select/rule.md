# Factor 插件接口规范

## 职责

对单只股票打分。返回 `None` 表示该因子一票否决；返回 dict 则参与合成。
**不负责仓位与下单。**

## 必须暴露的模块级属性

| 属性 | 类型 | 说明 |
|------|------|------|
| NAME | str | 因子名称 |
| WEIGHT | float | 合成权重（默认 1.0） |
| NEED_BARS | int | 取数 K 线数 |
| MIN_BARS | int | 最少 K 线，不足则跳过 |
| IDX_NEED_BARS | int | 指数所需 K 线（可选，默认 70） |

## 必须实现的函数

```python
def score_stock(fctx) -> dict | None:
    """
    fctx: FactorContext
      - symbol, stock (DataFrame), index, index_close, total_asset, today
    返回:
      {"score": float in [0,1], "detail": str, ...任意扩展字段}
      或 None（过滤）
    """
```

## 合成算法（`select/__init__.py`）

由 `WEIGHT_MODE` 控制：

1. **`rank`（默认）**  
   - 仅保留「所有启用因子均返回非 None」的股票  
   - 对每个因子的原始分做截面百分位 rank → [0, 1]  
   - `final = Σ(rank_i * w_i) / Σ w_i`  
   - 再按 `MIN_BUY_SCORE`（在 strategy/portfolio 侧）过滤

2. **`raw`**  
   - 经典加权平均：`Σ(score_i * w_i) / Σ w_i`  
   - 任一因子返回 None 则整票否决（与旧逻辑一致）

注册列表：

```python
FACTORS = [
    factor_03_v4_alpha,   # 使用模块 WEIGHT
    # 或 (factor_01_rps, 0.3),  # 覆盖权重
]
```

## 预留扩展

- `fctx.extra: dict` — 未来可传行业、财务等
- 因子可返回 `alpha_score` / `atr_pct` 等供 portfolio 使用，合成只读 `score`
