# -*- coding: utf-8 -*-
"""因子04：量能统计确认（周趋势友好）

来源思路：QuantSkills volume-stat-alpha
  - 10d z-scored volume expansion
  - 10d z-scored OBV slope
  - 10d price-volume correlation
  - 5/20 volume ratio + dollar activity

用途（实盘可研究）：
  - 作为 DefaultStrategy 多因子合成中的确认项（非纯 alpha）
  - 硬过滤流动性/缩量/OBV 背离；软分参与 rank 合成
  - 日频 10 日窗口 ≈ 周确认，不强制周 K，保留最短交易区间灵活性
"""
from __future__ import annotations

import numpy as np

from strategy.volume_confirm import evaluate, MIN_CONFIRM_SCORE

NAME = "量能统计确认V1"
WEIGHT = 0.35
NEED_BARS = 60
MIN_BARS = 45
IDX_NEED_BARS = 30
MIN_SCORE = MIN_CONFIRM_SCORE


def score_stock(fctx):
    data = fctx.stock
    if data is None or len(data) < MIN_BARS:
        return None
    try:
        close = data["close"].astype(float).values
        volume = data["volume"].astype(float).values
    except Exception:
        return None
    if not (np.all(np.isfinite(close)) and np.all(np.isfinite(volume))):
        return None

    result = evaluate(close, volume, price=float(close[-1]), min_score=MIN_SCORE)
    if not result["ok"]:
        return None

    return {
        "score": float(result["score"]),
        "detail": result["detail"],
        "volume_confirm": float(result["score"]),
        "vol_metrics": result["metrics"],
    }
