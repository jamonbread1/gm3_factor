# -*- coding: utf-8 -*-
"""
因子01：RPS20 超额动量 —— 星跃凌云策略的当前选股逻辑（原样迁入，规则零改动）

规则（与原 get_strong_stocks 完全一致）：
  1. 20日收益率相对沪深300的超额收益 excess_ret = ret_20 - idx_ret
  2. 现价不低于 MA20
  3. 现价不低于 10 日前收盘价
  4. score = clip((excess_ret + 0.1) / 0.2, 0, 1)，仅保留 score > 0.1

因子接口约定（后续新增因子请保持一致）：
  NAME          因子名称
  WEIGHT        多因子合成时的权重（加权平均）
  NEED_BARS     个股打分需要的K线数（取数用）
  MIN_BARS      少于该K线数直接放弃该股
  IDX_NEED_BARS 指数统计需要的K线数（取数用）
  score_stock(fctx) -> dict{'score','detail',...} 或 None
      返回 None 表示被该因子过滤（一票否决）
"""
import numpy as np

NAME = "RPS20超额动量"
WEIGHT = 1.0

LOOKBACK_RPS = 20
NEED_BARS = LOOKBACK_RPS + 10      # 需要回看10日做对比
IDX_NEED_BARS = LOOKBACK_RPS + 5
MIN_BARS = LOOKBACK_RPS
SCORE_MIN = 0.1


def score_stock(fctx):
    """对单只股票打分。

    fctx: FactorContext（stock=个股日线DF, index_close=指数收盘ndarray）
    返回 dict{'score','detail'}；不符合条件返回 None。
    """
    if fctx.stock is None or len(fctx.stock) < MIN_BARS:
        return None
    closes = fctx.stock["close"].values
    index_closes = fctx.index_close
    if index_closes is None or len(index_closes) < LOOKBACK_RPS:
        return None

    idx_close_now = index_closes[-1]
    idx_close_prev = index_closes[-LOOKBACK_RPS]
    idx_ret = (idx_close_now - idx_close_prev) / idx_close_prev if idx_close_prev != 0 else 0

    ret_20 = (closes[-1] - closes[-LOOKBACK_RPS]) / closes[-LOOKBACK_RPS]
    excess_ret = ret_20 - idx_ret

    ma20 = np.mean(closes[-20:])
    cur_price = closes[-1]
    if cur_price < ma20:
        return None

    if len(closes) >= 10:
        if closes[-1] < closes[-10]:
            return None

    score = max(0, min(1, (excess_ret + 0.1) / 0.2))

    if score > SCORE_MIN:
        return {"score": float(score), "detail": f"RPS:{excess_ret:.2%}"}
    return None
