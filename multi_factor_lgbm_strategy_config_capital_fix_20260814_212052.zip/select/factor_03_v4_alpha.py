# -*- coding: utf-8 -*-
"""V4 alpha factor.
Alpha measures stock quality only. Regime and capital efficiency are intentionally
not multiplied into alpha; they belong to portfolio sizing.
"""
import numpy as np

NAME = "三层选股模型V4 Alpha"
WEIGHT = 1.0
NEED_BARS = 80
MIN_BARS = 70
IDX_NEED_BARS = 70
MIN_PRICE = 3.0
MIN_AVG_AMOUNT = 3e6
MAX_ATR_PCT = 0.12
MIN_SCORE = 0.55


def clip(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, float(x)))


def score_stock(fctx):
    data = fctx.stock
    idx = fctx.index_close
    if data is None or len(data) < MIN_BARS or idx is None or len(idx) < 61:
        return None
    try:
        close = data["close"].astype(float).values
        high = data["high"].astype(float).values
        low = data["low"].astype(float).values
        volume = data["volume"].astype(float).values
    except Exception:
        return None
    if not all(np.all(np.isfinite(x)) for x in (close, high, low, volume, idx)):
        return None
    price = float(close[-1])
    if price < MIN_PRICE or price <= 0:
        return None

    avg_amount20 = float(np.mean(volume[-20:])) * price
    if avg_amount20 < MIN_AVG_AMOUNT:
        return None

    ma5 = float(np.mean(close[-5:]))
    ma20 = float(np.mean(close[-20:]))
    ma60 = float(np.mean(close[-60:]))
    ma20_prev = float(np.mean(close[-25:-5]))
    ma60_prev = float(np.mean(close[-70:-10]))
    ma20_slope = ma20 / ma20_prev - 1 if ma20_prev > 0 else 0
    ma60_slope = ma60 / ma60_prev - 1 if ma60_prev > 0 else 0
    if price < ma20 * 0.96 or ma20 < ma60 * 0.97:
        return None

    ret20 = price / close[-20] - 1
    ret60 = price / close[-60] - 1
    idx_ret20 = idx[-1] / idx[-20] - 1
    idx_ret60 = idx[-1] / idx[-60] - 1
    excess20 = ret20 - idx_ret20
    excess60 = ret60 - idx_ret60
    rs20 = clip((excess20 + 0.05) / 0.15)
    rs60 = clip((excess60 + 0.10) / 0.30)

    ret5 = price / close[-5] - 1
    ret10 = price / close[-10] - 1
    momentum = 0.30 * (ret5 > 0) + 0.20 * (ret5 > 0.03) + 0.30 * (ret10 > 0) + 0.20 * (ret10 > 0.05)
    momentum = clip(momentum)
    if ret5 > 0.15:
        momentum *= 0.75
    elif ret5 > 0.10:
        momentum *= 0.90

    trend = 0.0
    if price > ma5: trend += 0.15
    if price > ma20: trend += 0.25
    elif price > ma20 * 0.98: trend += 0.10
    if ma20 > ma60: trend += 0.25
    elif ma20 > ma60 * 0.98: trend += 0.10
    if ma20_slope > 0.03: trend += 0.20
    elif ma20_slope > 0: trend += 0.12
    if ma60_slope > 0: trend += 0.15
    trend = clip(trend)

    high20 = float(np.max(high[-20:]))
    low20 = float(np.min(low[-20:]))
    recovery = (price - low20) / (high20 - low20 + 1e-8)
    recovery_score = 0.30 if recovery < 0.35 else 0.55 if recovery < 0.55 else 0.80 if recovery < 0.75 else 1.00 if recovery < 0.90 else 0.90

    up, down = [], []
    for i in range(len(close) - 10, len(close)):
        if close[i] > close[i - 1]: up.append(volume[i])
        elif close[i] < close[i - 1]: down.append(volume[i])
    uv = float(np.mean(up)) if up else 0.0
    dv = float(np.mean(down)) if down else 1.0
    volume_confirmation = uv / (dv + 1e-8)
    volume_score = 1.0 if volume_confirmation > 1.30 else 0.80 if volume_confirmation > 1.05 else 0.55 if volume_confirmation > 0.85 else 0.25

    tr = np.maximum(high[1:] - low[1:], np.maximum(np.abs(high[1:] - close[:-1]), np.abs(low[1:] - close[:-1])))
    atr = float(np.mean(tr[-14:]))
    atr_pct = atr / price
    if atr_pct > MAX_ATR_PCT:
        return None
    risk_score = 0.50 if atr_pct > 0.10 else 0.70 if atr_pct > 0.08 else 0.90 if atr_pct > 0.05 else 1.0

    distance_high = price / high20 - 1 if high20 > 0 else 0
    rebound_risk = 0.0
    if excess20 > 0.08 and excess60 < -0.05: rebound_risk += 0.30
    if ma20_slope < -0.02: rebound_risk += 0.25
    if ma20_slope < -0.02 and ma60_slope < 0: rebound_risk += 0.20
    if distance_high < -0.20: rebound_risk += 0.25
    elif distance_high < -0.15: rebound_risk += 0.15
    if volume_score < 0.55: rebound_risk += 0.15
    rebound_quality = 1.0 - clip(rebound_risk)

    alpha = (rs20 * 0.30 + rs60 * 0.15 + trend * 0.20 + recovery_score * 0.15 + momentum * 0.10 + volume_score * 0.05 + risk_score * 0.05)
    alpha *= rebound_quality
    fake = excess20 > 0.08 and excess60 < -0.05 and ma20_slope < 0 and recovery < 0.70
    if fake: alpha *= 0.60
    breakout = excess20 > 0.08 and excess60 > 0.05 and ma20_slope > 0 and ma60_slope >= 0 and price >= high20 * 0.98 and volume_score >= 0.80
    if breakout: alpha *= 1.05

    final = clip(alpha)
    if final < MIN_SCORE:
        return None
    detail = "RS20:%+.1f%% RS60:%+.1f%% trend:%.2f rebound:%.2f ATR:%.1f%%" % (excess20 * 100, excess60 * 100, trend, rebound_quality, atr_pct * 100)
    return {"score": final, "detail": detail, "alpha_score": final, "atr_pct": atr_pct, "true_breakout": breakout, "fake_rebound": fake}
